import '../../styles/Static.css';

export default function StaticPagesLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}