import { Metadata } from 'next';
import { fetchVideosContent, fetchVideoPlatforms } from '@/lib/serverData';
import SocialVideosPageClient from '@/components/client/pages/SocialVideosPageClient';
import type { VideoPlatformCount } from '@/lib/clientData';

interface VideosPageProps {
  searchParams: Promise<{
    platform?: string;
    page?: string;
  }>;
}

export async function generateMetadata({ searchParams }: VideosPageProps): Promise<Metadata> {
  const params = await searchParams;
  const platform = params.platform || 'all';
  
  const platformTitle = platform === 'all' 
    ? 'All Platforms' 
    : platform.charAt(0).toUpperCase() + platform.slice(1);
  
  return {
    title: `Social Videos - ${platformTitle} | VybesTribe`,
    description: `Watch the latest videos from ${platformTitle}. Curated social media content from YouTube, TikTok, Instagram, and more.`,
    openGraph: {
      title: `Social Videos - ${platformTitle}`,
      description: `Watch trending videos from ${platformTitle} on VybesTribe`,
      type: 'website',
    },
  };
}

export default async function VideosPage({ searchParams }: VideosPageProps) {
  const params = await searchParams;
  const platform = params.platform || 'all';
  const page = params.page ? parseInt(params.page, 10) : 1;
  
  const validPage = Math.max(1, isNaN(page) ? 1 : page);
  
  try {
    const [videosContent, platformsData] = await Promise.all([
      fetchVideosContent(validPage, 12, platform),
      fetchVideoPlatforms()
    ]);

    const safePlatforms: VideoPlatformCount[] = platformsData.platforms;

    return (
      <SocialVideosPageClient
        initialData={{
          articles: videosContent.articles,
          total_videos: videosContent.total_videos
        }}
        initialPlatforms={safePlatforms}
        selectedPlatform={platform}
        initialPage={validPage}
      />
    );
  } catch (error) {
    console.error('[VIDEOS PAGE] Error loading videos:', error);
    
    return (
      <SocialVideosPageClient
        initialData={{
          articles: [],
          total_videos: 0
        }}
        initialPlatforms={[]}
        selectedPlatform={platform}
        initialPage={validPage}
      />
    );
  }
}

export const revalidate = 300;

export async function generateStaticParams() {
  return [
    { platform: 'all' },
    { platform: 'youtube' },
    { platform: 'tiktok' },
    { platform: 'instagram' },
    { platform: 'facebook' },
  ].map(params => ({
    searchParams: params
  }));
}