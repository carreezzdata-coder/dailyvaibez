//app/admin/roles/page.tsx

'use client';

import UserRoles from '@/components/admin/UserRoles';

export default function Page() {
  return <UserRoles />;
}