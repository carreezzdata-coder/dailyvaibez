//app/admin/posts/page.tsx

'use client';

import RetrievePosts from '@/components/admin/RetrievePosts';

export default function Page() {
  return <RetrievePosts />;
}