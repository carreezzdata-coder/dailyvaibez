//app/admin/posts/pending/page.tsx

'use client';

import PendingApprovals from '@/components/admin/PendingApprovals';

export default function Page() {
  return <PendingApprovals />;
}