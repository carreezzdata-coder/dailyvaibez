
//app/admin/posts/create/page.tsx

'use client';

import CreatePosts from '@/components/admin/CreatePosts';

export default function Page() {
  return <CreatePosts />;
}