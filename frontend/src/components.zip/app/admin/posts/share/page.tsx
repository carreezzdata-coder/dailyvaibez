//app/admin/posts/share/page.tsx
'use client';

import SharePosts from '@/components/admin/SharePosts';

export default function Page() {
  return <SharePosts />;
}