// frontend/src/app/admin/messages/page.tsx
'use client';

import AdminMessages from '@/components/admin/AdminMessages';

export default function MessagesPage() {
  return <AdminMessages />;
}