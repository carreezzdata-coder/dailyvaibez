// app/admin/analytics/page.tsx
'use client';

import Analytics from '@/components/admin/Analytics';

export default function Page() {
  return <Analytics />;
}