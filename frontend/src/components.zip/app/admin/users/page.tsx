//app/admin/users/page.tsx

'use client';

import Users from '@/components/admin/Users';

export default function Page() {
  return <Users />;
}