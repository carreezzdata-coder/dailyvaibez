//app/admin/quotes/create/page.tsx
'use client';

import CreateQuote from '@/components/admin/CreateQuote';

export default function Page() {
  return <CreateQuote />;
}