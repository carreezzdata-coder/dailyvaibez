//app/admin/quotes/manage/page.tsx
'use client';

import ManageQuotes from '@/components/admin/ManageQuotes';

export default function Page() {
  return <ManageQuotes />;
}