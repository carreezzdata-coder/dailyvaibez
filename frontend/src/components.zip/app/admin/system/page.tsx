//app/admin/system/page.tsx

'use client';

import SystemServices from '@/components/admin/SystemServices';

export default function Page() {
  return <SystemServices />;
}