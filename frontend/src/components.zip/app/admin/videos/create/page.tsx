// frontend/src/app/admin/videos/create/page.tsx
'use client';

import SocialVideos from '@/components/admin/videos/SocialVideos';

export default function CreateVideoPage() {
  return <SocialVideos />;
}