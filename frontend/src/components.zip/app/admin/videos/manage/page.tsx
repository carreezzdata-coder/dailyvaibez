import ManageVideos from '@/components/admin/videos/ManageVideos';

export default function ManageVideosPage() {
  return <ManageVideos />;
}