import React, { useState, useEffect, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useSession } from '@/components/includes/Session';
import { usePermissions } from './adminhooks/usePermissions';
import EditStage1 from './editors/EditStage1';
import EditStage2 from './editors/EditStage2';
import EditStage3 from './editors/EditStage3';

interface Category {
  category_id: number;
  name: string;
  slug: string;
  parent_id: number | null;
  group?: string;
  description?: string;
  color?: string;
  icon?: string;
}

interface CategoryGroup {
  title: string;
  icon: string;
  description: string;
  color: string;
  parent_category: {
    category_id: number;
    name: string;
    slug: string;
    color?: string;
    icon?: string;
  } | null;
  categories: Category[];
  mainSlug: string;
}

interface Stage1Data {
  title: string;
  category_ids: number[];
  primary_category_id: string;
  priority: 'high' | 'medium' | 'low';
}

interface ImageFile {
  id: string;
  file?: File;
  image_id?: number;
  preview: string;
  caption: string;
  order: number;
  isFeatured: boolean;
  isUploading?: boolean;
  hasWatermark?: boolean;
  isExisting?: boolean;
}

interface Stage2Data {
  content: string;
  excerpt: string;
  images: ImageFile[];
  existing_images?: ImageFile[];
}

interface SocialMediaLink {
  platform: 'youtube_video' | 'youtube_short' | 'twitter_post' | 'twitter_video' | 
            'instagram_post' | 'instagram_reel' | 'instagram_video' | 'facebook_post' | 
            'facebook_video' | 'facebook_reel' | 'tiktok_video' | 'tiktok_reel' | 
            'linkedin_post' | 'threads_post' | 'x_post' | 'x_video';
  post_type: 'post' | 'reel' | 'video' | 'short' | 'story' | 'status';
  post_url: string;
  display_order: number;
  auto_embed?: boolean;
  show_full_embed?: boolean;
  is_featured?: boolean;
  caption?: string;
}

interface Stage3Data {
  tags: string;
  meta_description: string;
  seo_keywords: string;
  social_media_links: SocialMediaLink[];
}

interface User {
  admin_id: number;
  first_name: string;
  last_name: string;
  role: string;
}

const EditPost: React.FC = () => {
  const params = useParams();
  const router = useRouter();
  const newsId = params?.id as string;
  const { user: sessionUser, csrfToken, isAuthenticated } = useSession();
  const { 
    canPublish, 
    canCreatePosts,
    requiresApproval,
    isLoading: permissionsLoading 
  } = usePermissions();

  const [currentStage, setCurrentStage] = useState<1 | 2 | 3>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [message, setMessage] = useState<{ type: 'success' | 'error' | 'warning'; text: string } | null>(null);
  
  const [categoryGroups, setCategoryGroups] = useState<CategoryGroup[]>([]);
  const [allCategories, setAllCategories] = useState<Category[]>([]);
  const [categoriesError, setCategoriesError] = useState<string | null>(null);
  const [categoriesLoading, setCategoriesLoading] = useState(true);

  const submitControllerRef = useRef<AbortController | null>(null);

  const [stage1Data, setStage1Data] = useState<Stage1Data>({
    title: '',
    category_ids: [],
    primary_category_id: '',
    priority: 'medium'
  });

  const [stage2Data, setStage2Data] = useState<Stage2Data>({
    content: '',
    excerpt: '',
    images: [],
    existing_images: []
  });

  const [stage3Data, setStage3Data] = useState<Stage3Data>({
    tags: '',
    meta_description: '',
    seo_keywords: '',
    social_media_links: []
  });

  const fetchCategories = async () => {
    setCategoriesLoading(true);
    setCategoriesError(null);
    
    try {
      const response = await fetch('/api/admin/createposts?endpoint=categories', {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch categories: ${response.statusText}`);
      }

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.message || 'Failed to load categories');
      }

      const groups = data.groups || {};
      const groupsArray: CategoryGroup[] = [];
      const categoriesFlat: Category[] = [];

      Object.keys(groups).forEach((key) => {
        const group = groups[key];
        const mainSlug = key;

        groupsArray.push({
          title: group.title,
          icon: group.icon,
          description: group.description,
          color: group.color,
          parent_category: group.parent_category,
          categories: group.categories || [],
          mainSlug
        });

        if (group.categories && Array.isArray(group.categories)) {
          group.categories.forEach((cat: Category) => {
            categoriesFlat.push({
              ...cat,
              group: mainSlug
            });
          });
        }
      });

      setCategoryGroups(groupsArray);
      setAllCategories(categoriesFlat);
    } catch (error) {
      console.error('[Categories] Error:', error);
      setCategoriesError(error instanceof Error ? error.message : 'Unknown error');
    } finally {
      setCategoriesLoading(false);
    }
  };

  const fetchPostData = async () => {
    try {
      console.log('[Edit Post] Fetching data for ID:', newsId);
      
      const response = await fetch(`/api/admin/edit/${newsId}`, {
        method: 'GET',
        credentials: 'include',
        headers: { 
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken || '',
          'Cache-Control': 'no-cache'
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `Failed to fetch post: ${response.status}`);
      }

      const data = await response.json();
      console.log('[Edit Post] Data received:', data);
      
      if (data.success && data.news) {
        const news = data.news;
        
        setStage1Data({
          title: news.title || '',
          category_ids: news.category_ids || [],
          primary_category_id: news.primary_category_id?.toString() || '',
          priority: news.priority || 'medium'
        });

        const existingImages = (news.images_data || []).map((img: any) => ({
          id: `existing-${img.image_id}`,
          image_id: img.image_id,
          preview: img.image_path || img.image_url,
          caption: img.caption || img.image_caption || '',
          order: img.order || img.display_order || 0,
          isFeatured: img.is_featured || false,
          hasWatermark: img.has_watermark || (img.metadata?.has_watermark) || false,
          isExisting: true
        }));

        setStage2Data({
          content: news.content || '',
          excerpt: news.excerpt || '',
          images: [],
          existing_images: existingImages
        });

        setStage3Data({
          tags: news.tags || '',
          meta_description: news.meta_description || '',
          seo_keywords: news.seo_keywords || '',
          social_media_links: news.social_media_links || []
        });

        console.log('[Edit Post] State updated successfully');
      } else {
        throw new Error('Invalid post data response');
      }
    } catch (error) {
      console.error('[Edit Post] Fetch error:', error);
      setMessage({
        type: 'error',
        text: error instanceof Error ? error.message : 'Failed to load post data'
      });
      setTimeout(() => router.push('/admin/posts'), 2000);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    if (!categoriesLoading && newsId && csrfToken) {
      fetchPostData();
    }
  }, [categoriesLoading, newsId, csrfToken]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentStage]);

  const handleStage1Submit = (data: Stage1Data) => {
    setStage1Data(data);
    setCurrentStage(2);
  };

  const handleStage2Submit = (data: Stage2Data) => {
    setStage2Data(data);
    setCurrentStage(3);
  };

  const handleStage3Submit = async (data: Stage3Data, actionType: 'draft' | 'publish') => {
    setStage3Data(data);
    await handleFinalSubmit(data, actionType);
  };

  const handleFinalSubmit = async (data: Stage3Data, actionType: 'draft' | 'publish') => {
    if (isSubmitting) return;
    setIsSubmitting(true);
    setMessage(null);

    submitControllerRef.current?.abort();
    const controller = new AbortController();
    submitControllerRef.current = controller;

    try {
      if (!sessionUser?.admin_id) {
        throw new Error('User authentication required');
      }

      if (stage1Data.category_ids.length === 0) {
        throw new Error('Please select at least one category');
      }

      if (!stage1Data.primary_category_id) {
        throw new Error('Please select a primary category');
      }

      const formData = new FormData();

      formData.append('title', stage1Data.title.trim());
      formData.append('content', stage2Data.content.trim());
      formData.append('excerpt', stage2Data.excerpt.trim() || stage1Data.title.substring(0, 200) + '...');
      formData.append('category_ids', JSON.stringify(stage1Data.category_ids));
      formData.append('primary_category_id', stage1Data.primary_category_id.toString());
      formData.append('priority', stage1Data.priority);
      formData.append('tags', data.tags.trim());
      formData.append('meta_description', data.meta_description.trim());
      formData.append('seo_keywords', data.seo_keywords.trim());
      formData.append('status', actionType === 'publish' ? 'published' : 'draft');
      formData.append('author_id', sessionUser.admin_id.toString());

      if (data.social_media_links && data.social_media_links.length > 0) {
        const validLinks = data.social_media_links
          .filter(link => link.post_url && link.post_url.trim())
          .map((link, index) => ({
            platform: link.platform,
            post_type: link.post_type,
            post_url: link.post_url.trim(),
            display_order: link.display_order || (index + 2),
            auto_embed: link.auto_embed !== false,
            show_full_embed: link.show_full_embed !== false,
            is_featured: link.is_featured || false,
            caption: link.caption || ''
          }));

        formData.append('social_media_links', JSON.stringify(validLinks));
      } else {
        formData.append('social_media_links', '[]');
      }

      const existingImagesData = (stage2Data.existing_images || []).map(img => ({
        image_id: img.image_id,
        image_path: img.preview,
        caption: img.caption,
        order: img.order,
        is_featured: img.isFeatured,
        has_watermark: img.hasWatermark || false
      }));
      formData.append('existing_images', JSON.stringify(existingImagesData));

      if (stage2Data.images && stage2Data.images.length > 0) {
        stage2Data.images.forEach((img, index) => {
          if (img.file) {
            formData.append('new_images', img.file);
            formData.append(`new_image_metadata_${index}`, JSON.stringify({
              caption: img.caption || '',
              order: img.order + (stage2Data.existing_images?.length || 0),
              is_featured: img.isFeatured || false,
              has_watermark: img.hasWatermark || false
            }));
          }
        });
      }

      console.log('[Edit Post] Submitting update...');

      const response = await fetch(`/api/admin/edit/${newsId}`, {
        method: 'PUT',
        headers: {
          'X-CSRF-Token': csrfToken || ''
        },
        credentials: 'include',
        body: formData,
        signal: controller.signal
      });

      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        const text = await response.text();
        throw new Error(`Server returned non-JSON response: ${text.substring(0, 100)}`);
      }

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.message || `Server error: ${response.status}`);
      }

      const requiresApprovalFlag = result.requires_approval || false;

      let successMessage = 'Article updated successfully';
      if (actionType === 'publish') {
        if (canPublish) {
          successMessage = '✅ Article Updated & Published Successfully';
        } else if (requiresApprovalFlag) {
          successMessage = '📤 Updated & Submitted for approval';
        } else {
          successMessage = '💾 Draft Updated Successfully';
        }
      } else {
        successMessage = '💾 Draft Updated Successfully';
      }

      setMessage({ 
        type: 'success', 
        text: successMessage
      });

      setTimeout(() => {
        router.push('/admin/posts');
      }, 2000);

    } catch (error) {
      if ((error as DOMException).name !== 'AbortError') {
        console.error('[Edit Post] Submit error:', error);
        setMessage({
          type: 'error',
          text: error instanceof Error ? error.message : 'Failed to update post'
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleBack = () => {
    if (currentStage === 2) {
      setCurrentStage(1);
    } else if (currentStage === 3) {
      setCurrentStage(2);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (permissionsLoading || categoriesLoading) {
    return (
      <div className="create-posts-loading">
        <div className="loading-spinner"></div>
        <p>Loading editor...</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="create-posts-loading">
        <div className="loading-spinner"></div>
        <p>Loading post data...</p>
      </div>
    );
  }

  if (!canCreatePosts) {
    return (
      <div className="admin-content">
        <div className="message error">
          You do not have permission to edit posts. Please contact an administrator.
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="admin-content">
        <div className="message error">
          Session expired. Please log in again.
        </div>
        <button onClick={() => router.push('/admin/login')} className="new-post-btn">
          Go to Login
        </button>
      </div>
    );
  }

  if (categoriesError) {
    return (
      <div className="admin-content">
        <div className="message error">
          Error loading categories: {categoriesError}
        </div>
        <button onClick={fetchCategories} className="new-post-btn">
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="create-posts">
      {message && (
        <div className={`message ${message.type}`}>
          {message.text}
        </div>
      )}

      {currentStage === 1 && (
        <EditStage1
          initialData={stage1Data}
          onNext={handleStage1Submit}
          categoryGroups={categoryGroups}
          allCategories={allCategories}
          categoriesError={categoriesError}
        />
      )}

      {currentStage === 2 && (
        <EditStage2
          initialData={stage2Data}
          onSubmit={handleStage2Submit}
          onBack={handleBack}
          maxImages={10}
        />
      )}

      {currentStage === 3 && (
        <EditStage3
          initialData={stage3Data}
          onSubmit={handleStage3Submit}
          onBack={handleBack}
          maxSocialLinks={5}
          canPublish={canPublish}
          requiresApproval={requiresApproval}
          isSubmitting={isSubmitting}
        />
      )}
    </div>
  );
};

export default EditPost;