'use client';

import { useState, useCallback } from 'react';

export interface Quote {
  quote_id: number;
  quote_text: string;
  sayer_name: string;
  sayer_title: string;
  sayer_image_url?: string;
  active: boolean;
  created_at: string;
  updated_at: string;
}

interface UseQuotesReturn {
  fetchQuotes: () => Promise<{
    quotes: Quote[];
    strikingQuotes: Quote[];
    trendingQuotes: Quote[];
  } | null>;
  isLoading: boolean;
  error: string | null;
}

export const useQuotes = (): UseQuotesReturn => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchQuotes = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/client/quotes', {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        cache: 'no-store'
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch quotes');
      }
      
      const data = await response.json();
      
      if (!data.success) {
        throw new Error(data.message || 'Failed to load quotes');
      }

      return {
        quotes: data.quotes || [],
        strikingQuotes: data.strikingQuotes || [],
        trendingQuotes: data.trendingQuotes || []
      };
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch quotes';
      setError(errorMessage);
      console.error('[useQuotes] Error:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  return { fetchQuotes, isLoading, error };
};