'use client';

import { useState, useEffect, useCallback } from 'react';
import { useCookieConfig } from '../cookies/useCookieConfig';
import { useClientSession } from './ClientSessions';

interface PersonalizedContent {
  featured: any[];
  timeline: any[];
  slider: any[];
  categorySections: any[];
}

export function usePersonalizedContent() {
  const { sessionToken } = useClientSession();
  const { userBehavior, preferences, geoLocation, hasConsent } = useCookieConfig();
  const [content, setContent] = useState<PersonalizedContent>({
    featured: [],
    timeline: [],
    slider: [],
    categorySections: []
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const buildPersonalizationPayload = useCallback(() => {
    if (!hasConsent || !preferences.personalization) {
      return {
        personalized: false,
        preferences: { preferredCategories: [] },
        location: { county: null, town: null }
      };
    }

    return {
      personalized: true,
      preferences: {
        preferredCategories: userBehavior.preferredCategories || [],
        categoryVisits: userBehavior.categoryVisits || {},
        totalVisits: userBehavior.totalVisits || 0
      },
      location: {
        county: geoLocation.county,
        town: geoLocation.town,
        category: geoLocation.category
      }
    };
  }, [hasConsent, preferences, userBehavior, geoLocation]);

  const fetchPersonalizedContent = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const payload = buildPersonalizationPayload();
      
      const response = await fetch('/api/client/personalized', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          ...(sessionToken && { 'Authorization': `Bearer ${sessionToken}` })
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      
      if (data.success) {
        setContent({
          featured: data.featured || [],
          timeline: data.timeline || [],
          slider: data.slider || [],
          categorySections: data.categorySections || []
        });
      }
    } catch (err) {
      console.error('Personalized content error:', err);
      setError(err instanceof Error ? err.message : 'Failed to load content');
    } finally {
      setIsLoading(false);
    }
  }, [sessionToken, buildPersonalizationPayload]);

  useEffect(() => {
    fetchPersonalizedContent();
  }, [fetchPersonalizedContent]);

  return {
    content,
    isLoading,
    error,
    refresh: fetchPersonalizedContent,
    isPersonalized: hasConsent && preferences.personalization
  };
}

export function usePersonalizedSlider() {
  const { sessionToken } = useClientSession();
  const { userBehavior, preferences, hasConsent } = useCookieConfig();
  const [slides, setSlides] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchSlides = useCallback(async () => {
    setIsLoading(true);

    try {
      const payload = {
        personalized: hasConsent && preferences.personalization,
        preferredCategories: userBehavior.preferredCategories || [],
        limit: 8
      };

      const response = await fetch('/api/client/slider/personalized', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          ...(sessionToken && { 'Authorization': `Bearer ${sessionToken}` })
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      setSlides(data.slides || []);
    } catch (err) {
      console.error('Slider fetch error:', err);
    } finally {
      setIsLoading(false);
    }
  }, [sessionToken, hasConsent, preferences, userBehavior]);

  useEffect(() => {
    fetchSlides();
  }, [fetchSlides]);

  return { slides, isLoading, refresh: fetchSlides };
}

export function usePersonalizedTimeline(initialPage = 1) {
  const { sessionToken } = useClientSession();
  const { userBehavior, preferences, hasConsent } = useCookieConfig();
  const [articles, setArticles] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(initialPage);

  const fetchTimeline = useCallback(async (pageNum: number, append = false) => {
    setIsLoading(true);

    try {
      const payload = {
        personalized: hasConsent && preferences.personalization,
        preferredCategories: userBehavior.preferredCategories || [],
        categoryVisits: userBehavior.categoryVisits || {},
        page: pageNum,
        limit: 20
      };

      const response = await fetch('/api/client/timeline/personalized', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          ...(sessionToken && { 'Authorization': `Bearer ${sessionToken}` })
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      
      if (append) {
        setArticles(prev => [...prev, ...(data.articles || [])]);
      } else {
        setArticles(data.articles || []);
      }
      
      setHasMore(data.pagination?.has_next || false);
    } catch (err) {
      console.error('Timeline fetch error:', err);
    } finally {
      setIsLoading(false);
    }
  }, [sessionToken, hasConsent, preferences, userBehavior]);

  const loadMore = useCallback(() => {
    if (!isLoading && hasMore) {
      const nextPage = page + 1;
      setPage(nextPage);
      fetchTimeline(nextPage, true);
    }
  }, [isLoading, hasMore, page, fetchTimeline]);

  useEffect(() => {
    fetchTimeline(1);
  }, [fetchTimeline]);

  return { articles, isLoading, hasMore, loadMore, refresh: () => fetchTimeline(1) };
}