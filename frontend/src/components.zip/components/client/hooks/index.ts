// src/components/client/hooks/index.ts

// Session Management
export { useClientSession, ClientSessionProvider } from './ClientSessions';
export type { ClientSessionData, ClientSessionContextType } from './ClientSessions';

// User Preferences & Behavior
export { useUserPreferences } from './useUserPreferences';
export type { 
  UserPreferences, 
  CategoryVisit as UserCategoryVisit, 
  GeoLocation 
} from './useUserPreferences';

// Cookies Management
export { useCookies } from './useCookies';
export type { CookiePreferences, UserBehavior } from './useCookies';

// Category Management
export { useCategory } from './useCategory';
export type { Category } from './useCategory';

export { useCategoryFooter } from './useCategoryFooter';
export type { FooterCategory, CategoryGroup } from './useCategoryFooter';

// Article Management
export { useArticle } from './useArticle';
export type { NewsItem } from './useArticle';

// News Fetching
export { useFetchNews } from './useFetchNews';

// Advertisement Management
export { 
  useAdverts, 
  getAdsByPosition, 
  getRandomAds, 
  calculateAdPerformance 
} from './useAdverts';
export type { Advert, AdvertResponse, UseAdvertsReturn } from './useAdverts';

// Geo Location Tracking
export { useGeo } from './useGeo';
export { useGeoTracking } from './useGeoTracking';

// Home Page Data
export { useHome } from './useHome';

// Slider/Carousel
export { useSlider } from './useSlider';

// Backward compatibility aliases
export { useUserPreferences as usePreferences } from './useUserPreferences';

// Re-export everything for convenience
export * from './ClientSessions';
export * from './useUserPreferences';
export * from './useCookies';
export * from './useCategory';
export * from './useCategoryFooter';
export * from './useArticle';
export * from './useFetchNews';
export * from './useAdverts';
export * from './useGeo';
export * from './useGeoTracking';
export * from './useHome';
export * from './useSlider';