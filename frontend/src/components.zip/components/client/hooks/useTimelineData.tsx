import { useState, useEffect, useCallback } from 'react';
import { useClientSession } from './ClientSessions';
import { useCookieConfig } from '../cookies/useCookieConfig';
import { useUserPreferences } from './useUserPreferences';

interface Article {
  news_id: number;
  title: string;
  slug: string;
  image_url: string | null;
  category_name: string;
  category_slug: string;
  published_at: string;
  views: number;
  likes_count: number;
  first_name?: string;
  last_name?: string;
  excerpt?: string;
  reading_time?: number;
}

interface Pagination {
  current_page: number;
  per_page: number;
  has_next: boolean;
  has_prev: boolean;
}

interface UseTimelineDataReturn {
  articles: Article[];
  isLoading: boolean;
  isLoadingMore: boolean;
  error: string | null;
  hasMore: boolean;
  loadMore: () => Promise<void>;
  refresh: () => Promise<void>;
  isPersonalized: boolean;
}

export function useTimelineData(): UseTimelineDataReturn {
  const { sessionToken } = useClientSession();
  const { userBehavior, preferences, hasConsent } = useCookieConfig();
  const { preferences: userPrefs, geoLocation, isHydrated } = useUserPreferences();
  
  const [articles, setArticles] = useState<Article[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasFetched, setHasFetched] = useState(false);
  const [pagination, setPagination] = useState<Pagination>({
    current_page: 1,
    per_page: 20,
    has_next: false,
    has_prev: false
  });

  const isPersonalized = isHydrated && hasConsent && preferences.personalization;

  const fetchArticles = useCallback(async (page: number, append: boolean = false) => {
    if (!isHydrated) return;
    
    try {
      if (append) {
        setIsLoadingMore(true);
      } else {
        setIsLoading(true);
      }
      setError(null);

      if (isPersonalized && page === 1) {
        const payload = {
          personalized: true,
          preferences: {
            preferredCategories: userBehavior.preferredCategories || userPrefs.favoriteCategories || [],
            categoryVisits: userBehavior.categoryVisits || {},
            totalVisits: userBehavior.totalVisits || 0
          },
          location: {
            county: geoLocation.county,
            town: geoLocation.town,
            category: geoLocation.category
          },
          page,
          limit: 20
        };

        const response = await fetch('/api/client/personalized', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            ...(sessionToken && { 'Authorization': `Bearer ${sessionToken}` })
          },
          body: JSON.stringify(payload)
        });

        if (response.ok) {
          const data = await response.json();
          
          if (data.success && Array.isArray(data.timeline)) {
            if (append) {
              setArticles(prev => [...prev, ...data.timeline]);
            } else {
              setArticles(data.timeline);
            }
            
            setPagination({
              current_page: page,
              per_page: 20,
              has_next: data.timeline.length === 20,
              has_prev: page > 1
            });
            
            setHasFetched(true);
            return;
          }
        }
      }

      const response = await fetch(`/api/client/timeline?page=${page}&limit=20&_t=${Date.now()}`, {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          ...(sessionToken && { 'Authorization': `Bearer ${sessionToken}` })
        },
        cache: 'no-store'
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success && Array.isArray(data.articles)) {
        if (append) {
          setArticles(prev => [...prev, ...data.articles]);
        } else {
          setArticles(data.articles);
        }
        
        if (data.pagination) {
          setPagination(data.pagination);
        }
      } else {
        if (!append) {
          setArticles([]);
        }
      }
      
      setHasFetched(true);

    } catch (err) {
      console.error('[useTimelineData] Error:', err);
      setError(err instanceof Error ? err.message : 'Failed to load timeline');
      if (!append) {
        setArticles([]);
      }
    } finally {
      setIsLoading(false);
      setIsLoadingMore(false);
    }
  }, [sessionToken, isPersonalized, userBehavior, userPrefs, geoLocation, isHydrated]);

  const loadMore = useCallback(async () => {
    if (isLoadingMore || !pagination.has_next) return;
    
    const nextPage = pagination.current_page + 1;
    await fetchArticles(nextPage, true);
  }, [isLoadingMore, pagination, fetchArticles]);

  const refresh = useCallback(async () => {
    await fetchArticles(1, false);
  }, [fetchArticles]);

  useEffect(() => {
    if (isHydrated && !hasFetched) {
      fetchArticles(1, false);
    }
  }, [isHydrated, hasFetched, fetchArticles]);

  return {
    articles,
    isLoading,
    isLoadingMore,
    error,
    hasMore: pagination.has_next,
    loadMore,
    refresh,
    isPersonalized
  };
}