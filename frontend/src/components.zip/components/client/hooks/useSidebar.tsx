'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useClientSession } from './ClientSessions';
import type { NewsItem } from './useArticle';

interface UseSidebarReturn {
  featured: NewsItem[];
  trending: NewsItem[];
  isLoading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

const normalizeNewsItem = (item: any): NewsItem => {
  const tags = Array.isArray(item.tags) ? item.tags : 
    (typeof item.tags === 'string' && item.tags ? item.tags.split(',').map((t: string) => t.trim()).filter(Boolean) : []);
  const seoKeywords = Array.isArray(item.seo_keywords) ? item.seo_keywords :
    (typeof item.seo_keywords === 'string' && item.seo_keywords ? item.seo_keywords.split(',').map((k: string) => k.trim()).filter(Boolean) : []);

  return {
    news_id: item.news_id || 0,
    title: item.title || 'Untitled',
    content: item.content || '',
    processed_content: item.processed_content || '',
    excerpt: item.excerpt || item.meta_description || '',
    slug: item.slug || '',
    category_id: item.category_id || 0,
    category_ids: item.category_ids || [],
    category_name: item.category_name || 'Uncategorized',
    category_slug: item.category_slug || 'uncategorized',
    category_color: item.category_color || '',
    featured: Boolean(item.featured),
    featured_until: item.featured_until || null,
    image_url: item.image_url || '',
    status: item.status || 'published',
    priority: item.priority || 'medium',
    tags,
    meta_description: item.meta_description || '',
    seo_keywords: seoKeywords,
    reading_time: parseInt(item.reading_time) || 5,
    views: parseInt(item.views) || 0,
    likes_count: parseInt(item.likes_count) || 0,
    comments_count: parseInt(item.comments_count) || 0,
    share_count: parseInt(item.share_count) || 0,
    first_name: item.first_name || 'Daily Vaibe',
    last_name: item.last_name || 'Editor',
    author_email: item.author_email || item.author?.email || '',
    published_at: item.published_at || new Date().toISOString(),
    created_at: item.created_at || new Date().toISOString(),
    updated_at: item.updated_at || new Date().toISOString(),
    youtube_url: item.youtube_url || item.youtube?.url || '',
    youtube_id: item.youtube_id || item.youtube?.id || '',
    youtube_title: item.youtube_title || item.youtube?.title || '',
    youtube_thumbnail: item.youtube_thumbnail || item.youtube?.thumbnail || '',
    youtube: item.youtube || (item.youtube_id ? {
      url: item.youtube_url, id: item.youtube_id,
      title: item.youtube_title, thumbnail: item.youtube_thumbnail
    } : null),
    images_data: item.images_data || [],
    social_videos: item.social_videos || [],
    additional_images: item.additional_images || [],
    quotes_data: item.quotes_data || [],
    seo: item.seo,
    author: item.author,
    category: item.category,
    all_images: item.all_images || [],
    all_videos: item.all_videos || [],
    all_categories: item.all_categories || []
  };
};

export const useSidebar = (): UseSidebarReturn => {
  const { sessionToken } = useClientSession();
  const [featured, setFeatured] = useState<NewsItem[]>([]);
  const [trending, setTrending] = useState<NewsItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const refreshIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const mountedRef = useRef(true);
  const cacheRef = useRef<{ featured: NewsItem[]; trending: NewsItem[]; timestamp: number } | null>(null);

  const fetchSidebar = useCallback(async (): Promise<{ featured: NewsItem[]; trending: NewsItem[] }> => {
    const now = Date.now();
    if (cacheRef.current && (now - cacheRef.current.timestamp) < 30000) {
      return { featured: cacheRef.current.featured, trending: cacheRef.current.trending };
    }

    try {
      const [featuredRes, trendingRes] = await Promise.all([
        fetch(`/api/client/featured?limit=12&_t=${now}`, {
          method: 'GET',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache',
            ...(sessionToken && { 'Authorization': `Bearer ${sessionToken}` })
          },
          cache: 'no-store'
        }),
        fetch(`/api/client/trending?limit=12&_t=${now}`, {
          method: 'GET',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache',
            ...(sessionToken && { 'Authorization': `Bearer ${sessionToken}` })
          },
          cache: 'no-store'
        })
      ]);

      let featuredArray: NewsItem[] = [];
      let trendingArray: NewsItem[] = [];

      if (featuredRes.ok) {
        const featuredResult = await featuredRes.json();
        if (featuredResult.success && Array.isArray(featuredResult.news)) {
          featuredArray = featuredResult.news.map(normalizeNewsItem);
        }
      }

      if (trendingRes.ok) {
        const trendingResult = await trendingRes.json();
        if (trendingResult.success && Array.isArray(trendingResult.news)) {
          trendingArray = trendingResult.news.map(normalizeNewsItem);
        }
      }

      cacheRef.current = {
        featured: featuredArray,
        trending: trendingArray,
        timestamp: now
      };

      return { featured: featuredArray, trending: trendingArray };
    } catch (err) {
      console.error('Error fetching sidebar:', err);
      return { featured: [], trending: [] };
    }
  }, [sessionToken]);

  const refresh = useCallback(async () => {
    if (!mountedRef.current) return;

    setIsLoading(true);
    setError(null);

    try {
      const { featured: featuredNews, trending: trendingNews } = await fetchSidebar();
      if (mountedRef.current) {
        setFeatured(featuredNews);
        setTrending(trendingNews);
      }
    } catch (err) {
      if (mountedRef.current) {
        setError(err instanceof Error ? err.message : 'Failed to refresh sidebar');
        setFeatured([]);
        setTrending([]);
      }
    } finally {
      if (mountedRef.current) {
        setIsLoading(false);
      }
    }
  }, [fetchSidebar]);

  useEffect(() => {
    mountedRef.current = true;

    refresh();

    refreshIntervalRef.current = setInterval(() => {
      if (mountedRef.current) refresh();
    }, 45000);

    return () => {
      mountedRef.current = false;
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current);
      }
    };
  }, [refresh]);

  return {
    featured,
    trending,
    isLoading,
    error,
    refresh
  };
};