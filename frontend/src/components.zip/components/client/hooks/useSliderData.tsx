import { useState, useEffect, useCallback } from 'react';
import { useClientSession } from './ClientSessions';
import { useCookieConfig } from '../cookies/useCookieConfig';
import { useUserPreferences } from './useUserPreferences';

interface SlideArticle {
  news_id: string | number;
  title: string;
  excerpt?: string;
  slug: string;
  image_url: string | null;
  published_at: string;
  reading_time?: number;
  views: number;
  likes_count?: number;
  comments_count?: number;
  first_name?: string;
  last_name?: string;
  category_name: string;
}

interface UseSliderDataReturn {
  slides: SlideArticle[];
  isLoading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  isPersonalized: boolean;
}

export function useSliderData(): UseSliderDataReturn {
  const { sessionToken } = useClientSession();
  const { userBehavior, preferences, hasConsent } = useCookieConfig();
  const { preferences: userPrefs, geoLocation, isHydrated } = useUserPreferences();
  
  const [slides, setSlides] = useState<SlideArticle[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasFetched, setHasFetched] = useState(false);

  const isPersonalized = isHydrated && hasConsent && preferences.personalization;

  const fetchSlides = useCallback(async () => {
    if (!isHydrated) return;
    
    setIsLoading(true);
    setError(null);

    try {
      if (isPersonalized) {
        const payload = {
          personalized: true,
          preferences: {
            preferredCategories: userBehavior.preferredCategories || userPrefs.favoriteCategories || [],
            categoryVisits: userBehavior.categoryVisits || {},
            totalVisits: userBehavior.totalVisits || 0
          },
          location: {
            county: geoLocation.county,
            town: geoLocation.town,
            category: geoLocation.category
          }
        };

        const response = await fetch('/api/client/personalized', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            ...(sessionToken && { 'Authorization': `Bearer ${sessionToken}` })
          },
          body: JSON.stringify(payload)
        });

        if (response.ok) {
          const data = await response.json();
          if (data.success && Array.isArray(data.slider)) {
            setSlides(data.slider);
            setHasFetched(true);
            return;
          }
        }
      }

      const response = await fetch('/api/client/homeslider?_t=' + Date.now(), {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        },
        cache: 'no-store'
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      if (data.success && Array.isArray(data.slides)) {
        setSlides(data.slides);
      } else {
        setSlides([]);
      }
      
      setHasFetched(true);

    } catch (err) {
      console.error('[useSliderData] Error:', err);
      setError(err instanceof Error ? err.message : 'Failed to load slides');
      setSlides([]);
    } finally {
      setIsLoading(false);
    }
  }, [sessionToken, isPersonalized, userBehavior, userPrefs, geoLocation, isHydrated]);

  const refresh = useCallback(async () => {
    await fetchSlides();
  }, [fetchSlides]);

  useEffect(() => {
    if (isHydrated && !hasFetched) {
      fetchSlides();
    }
  }, [isHydrated, hasFetched, fetchSlides]);

  return {
    slides,
    isLoading,
    error,
    refresh,
    isPersonalized
  };
}