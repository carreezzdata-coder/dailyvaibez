'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { formatDate, formatNumber, getImageUrl } from '../../../lib/clientData';
import { useFeatured } from '../hooks/useFeatured';
import Header from '../components/Header';
import Horizontal from '../components/Horizontal';
import Ribbon from '../components/Ribbon';
import Gallery from '../components/Gallery';
import Footer from '../components/Footer';

interface FeaturedPageClientProps {
  initialData: {
    news: any[];
    pagination: any;
  };
}

export default function FeaturedPageClient({ initialData }: FeaturedPageClientProps) {
  const router = useRouter();
  const [showGallery, setShowGallery] = useState(false);
  const [currentTheme, setCurrentTheme] = useState('white');
  const [showLeftSidebar, setShowLeftSidebar] = useState(false);
  const [showRightSidebar, setShowRightSidebar] = useState(false);
  const [isHeaderVisible, setIsHeaderVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  const { news, refresh, isLoading } = useFeatured(initialData.news);

  const config = { 
    title: 'Featured Stories', 
    icon: '⭐', 
    color: '#9b59b6', 
    badge: 'FEATURED' 
  };

  const level1News = news.slice(0, 1);
  const level2News = news.slice(1, 3);
  const level3News = news.slice(3, 6);
  const level4News = news.slice(6, 10);
  const remainingNews = news.slice(10);
  const recentNews = news.slice(0, 6);
  const popularNews = [...news].sort((a, b) => b.views - a.views).slice(0, 10);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('vybes-theme') || 'white';
      setCurrentTheme(savedTheme);
      document.documentElement.setAttribute('data-theme', savedTheme);
    }
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setIsHeaderVisible(false);
      } else {
        setIsHeaderVisible(true);
      }
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const handleThemeChange = (theme: string) => {
    setCurrentTheme(theme);
    document.documentElement.setAttribute('data-theme', theme);
    if (typeof window !== 'undefined') {
      localStorage.setItem('vybes-theme', theme);
    }
  };

  const handleArticleClick = (article: any) => {
    router.push(`/client/articles/${article.slug}`);
  };

  const truncateText = (text: string, maxLength: number) => {
    if (!text) return '';
    return text.length > maxLength ? text.slice(0, maxLength) + '...' : text;
  };

  const getReadingTime = (content: string) => {
    if (!content) return 1;
    const words = content.split(/\s+/).length;
    return Math.max(1, Math.ceil(words / 200));
  };

  if (showGallery) {
    return <Gallery allNews={news} onArticleClick={handleArticleClick} />;
  }

  return (
    <div className="featured-page">
      <div className={`header-wrapper ${isHeaderVisible ? 'visible' : 'hidden'}`}>
        <Header currentTheme={currentTheme} onThemeChange={handleThemeChange} />
      </div>
      <Horizontal activeCategory="home" />

      <Ribbon onArticleClick={handleArticleClick} />

      <main className="main-container">
        {news.length > 0 ? (
          <div className="featured-layout">
            <aside className="updates-left-sidebar">
              <h3 className="sidebar-title">📚 Recent Updates</h3>
              <div className="sidebar-article-list">
                {recentNews.map((article: any) => (
                  <div 
                    key={article.news_id} 
                    className="sidebar-article-item" 
                    onClick={() => handleArticleClick(article)} 
                    role="button" 
                    tabIndex={0}
                  >
                    <div className="sidebar-thumbnail">
                      {article.image_url ? (
                        <img 
                          src={getImageUrl(article.image_url) || ''} 
                          alt={article.title}
                          loading="lazy"
                          width="70"
                          height="70"
                        />
                      ) : (
                        <div className="thumbnail-placeholder">{config.icon}</div>
                      )}
                    </div>
                    <div className="sidebar-article-content">
                      <div className="sidebar-article-title">{article.title}</div>
                      <div className="sidebar-article-meta">
                        <span>{formatDate(article.published_at)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </aside>

            <div className="featured-center-content">
              {level1News.length > 0 && (
                <div className="featured-level-1">
                  {level1News.map((article: any) => (
                    <article 
                      key={article.news_id} 
                      className="featured-level-1-card"
                      onClick={() => handleArticleClick(article)}
                    >
                      <div className="featured-premium-badge" style={{ background: config.color }}>
                        <span className="premium-star">★</span>
                        EDITOR'S PICK
                      </div>
                      <div className="featured-level-1-image">
                        {article.image_url ? (
                          <img 
                            src={getImageUrl(article.image_url) || ''} 
                            alt={article.title}
                            loading="eager"
                            width="1200"
                            height="600"
                          />
                        ) : (
                          <div className="featured-image-placeholder" style={{ background: config.color }}>
                            {config.icon}
                          </div>
                        )}
                      </div>
                      <div className="featured-level-1-content">
                        <div className="featured-level-1-category" style={{ color: config.color }}>
                          {article.category_name}
                        </div>
                        <h2 className="featured-level-1-title">{article.title}</h2>
                        {article.excerpt && (
                          <p 
                            className="featured-level-1-excerpt"
                            dangerouslySetInnerHTML={{ 
                              __html: truncateText(article.excerpt, 250)
                                .replace(/\[HIGHLIGHT\](.*?)\[\/HIGHLIGHT\]/g, '<span class="excerpt-highlight">$1</span>')
                                .replace(/\[BOLD\](.*?)\[\/BOLD\]/g, '<strong class="excerpt-bold">$1</strong>')
                                .replace(/\[ITALIC\](.*?)\[\/ITALIC\]/g, '<em class="excerpt-italic">$1</em>')
                            }}
                          />
                        )}
                        <div className="featured-level-1-meta">
                          <div className="featured-level-1-author">
                            <span className="featured-author-avatar" style={{ background: config.color }}>
                              {article.first_name?.[0]}{article.last_name?.[0]}
                            </span>
                            <div className="featured-author-info">
                              <span className="featured-author-name">
                                {article.first_name} {article.last_name}
                              </span>
                              <span className="featured-author-date">
                                {formatDate(article.published_at)}
                              </span>
                            </div>
                          </div>
                          <div className="featured-level-1-stats">
                            <span>👁 {formatNumber(article.views)}</span>
                            <span>📖 {getReadingTime(article.content)} min</span>
                          </div>
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              )}

              {level2News.length > 0 && (
                <div className="featured-level-2">
                  {level2News.map((article: any) => (
                    <article 
                      key={article.news_id} 
                      className="featured-level-2-card"
                      onClick={() => handleArticleClick(article)}
                    >
                      <div className="featured-level-2-image">
                        {article.image_url ? (
                          <img 
                            src={getImageUrl(article.image_url) || ''} 
                            alt={article.title}
                            loading="lazy"
                            width="600"
                            height="400"
                          />
                        ) : (
                          <div className="featured-image-placeholder" style={{ background: config.color }}>
                            {config.icon}
                          </div>
                        )}
                      </div>
                      <div className="featured-level-2-content">
                        <div className="featured-level-2-category" style={{ color: config.color }}>
                          {article.category_name}
                        </div>
                        <h3 className="featured-level-2-title">{article.title}</h3>
                        {article.excerpt && (
                          <p 
                            className="featured-level-2-excerpt"
                            dangerouslySetInnerHTML={{ 
                              __html: truncateText(article.excerpt, 180)
                                .replace(/\[HIGHLIGHT\](.*?)\[\/HIGHLIGHT\]/g, '<span class="excerpt-highlight">$1</span>')
                                .replace(/\[BOLD\](.*?)\[\/BOLD\]/g, '<strong class="excerpt-bold">$1</strong>')
                                .replace(/\[ITALIC\](.*?)\[\/ITALIC\]/g, '<em class="excerpt-italic">$1</em>')
                            }}
                          />
                        )}
                        <div className="featured-level-2-meta">
                          <div className="featured-level-2-author">
                            <span className="featured-author-avatar" style={{ background: config.color }}>
                              {article.first_name?.[0]}{article.last_name?.[0]}
                            </span>
                            <span>{article.first_name} {article.last_name}</span>
                          </div>
                          <div className="featured-level-2-stats">
                            <span>🕒 {formatDate(article.published_at)}</span>
                            <span>👁 {formatNumber(article.views)}</span>
                          </div>
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              )}

              {level3News.length > 0 && (
                <div className="featured-level-3">
                  {level3News.map((article: any) => (
                    <article 
                      key={article.news_id} 
                      className="featured-level-3-card"
                      onClick={() => handleArticleClick(article)}
                    >
                      <div className="featured-level-3-image">
                        {article.image_url ? (
                          <img 
                            src={getImageUrl(article.image_url) || ''} 
                            alt={article.title}
                            loading="lazy"
                            width="400"
                            height="250"
                          />
                        ) : (
                          <div className="featured-image-placeholder" style={{ background: config.color }}>
                            {config.icon}
                          </div>
                        )}
                      </div>
                      <div className="featured-level-3-content">
                        <div className="featured-level-3-category" style={{ color: config.color }}>
                          {article.category_name}
                        </div>
                        <h3 className="featured-level-3-title">{article.title}</h3>
                        {article.excerpt && (
                          <p 
                            className="featured-level-3-excerpt"
                            dangerouslySetInnerHTML={{ 
                              __html: truncateText(article.excerpt, 120)
                                .replace(/\[HIGHLIGHT\](.*?)\[\/HIGHLIGHT\]/g, '<span class="excerpt-highlight">$1</span>')
                                .replace(/\[BOLD\](.*?)\[\/BOLD\]/g, '<strong class="excerpt-bold">$1</strong>')
                                .replace(/\[ITALIC\](.*?)\[\/ITALIC\]/g, '<em class="excerpt-italic">$1</em>')
                            }}
                          />
                        )}
                        <div className="featured-level-3-meta">
                          <div className="featured-level-3-author">
                            <span className="featured-author-avatar" style={{ background: config.color }}>
                              {article.first_name?.[0]}{article.last_name?.[0]}
                            </span>
                            <span>{article.first_name} {article.last_name}</span>
                          </div>
                          <div className="featured-level-3-stats">
                            <span>🕒 {formatDate(article.published_at)}</span>
                            <span>👁 {formatNumber(article.views)}</span>
                          </div>
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              )}

              {level4News.length > 0 && (
                <div className="featured-level-4">
                  {level4News.map((article: any) => (
                    <article 
                      key={article.news_id} 
                      className="featured-level-4-card"
                      onClick={() => handleArticleClick(article)}
                    >
                      <div className="featured-level-4-image">
                        {article.image_url ? (
                          <img 
                            src={getImageUrl(article.image_url) || ''} 
                            alt={article.title}
                            loading="lazy"
                            width="300"
                            height="200"
                          />
                        ) : (
                          <div className="featured-image-placeholder" style={{ background: config.color }}>
                            {config.icon}
                          </div>
                        )}
                      </div>
                      <div className="featured-level-4-content">
                        <div className="featured-level-4-category" style={{ color: config.color }}>
                          {article.category_name}
                        </div>
                        <h3 className="featured-level-4-title">{article.title}</h3>
                        <div className="featured-level-4-meta">
                          <div className="featured-level-4-author">
                            <span className="featured-author-avatar" style={{ background: config.color }}>
                              {article.first_name?.[0]}{article.last_name?.[0]}
                            </span>
                            <span>{article.first_name} {article.last_name}</span>
                          </div>
                          <div className="featured-level-4-stats">
                            <span>🕒 {formatDate(article.published_at)}</span>
                            <span>👁 {formatNumber(article.views)}</span>
                          </div>
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </div>

            <aside className="updates-right-sidebar">
              <h3 className="sidebar-title">🔥 Most Popular</h3>
              <div className="sidebar-article-list">
                {popularNews.map((article: any, index: number) => (
                  <div 
                    key={article.news_id} 
                    className="sidebar-article-item trending" 
                    onClick={() => handleArticleClick(article)} 
                    role="button" 
                    tabIndex={0}
                  >
                    <div className="popularity-rank" style={{ background: config.color }}>
                      {index + 1}
                    </div>
                    <div className="sidebar-thumbnail">
                      {article.image_url ? (
                        <img 
                          src={getImageUrl(article.image_url) || ''} 
                          alt={article.title}
                          loading="lazy"
                          width="70"
                          height="70"
                        />
                      ) : (
                        <div className="thumbnail-placeholder">{config.icon}</div>
                      )}
                    </div>
                    <div className="sidebar-article-content">
                      <div className="sidebar-article-title">{article.title}</div>
                      <div className="sidebar-article-meta">
                        <span>👁 {formatNumber(article.views)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </aside>
          </div>
        ) : (
          <div className="empty-state">
            <div className="empty-icon" style={{ color: config.color }}>
              {config.icon}
            </div>
            <h3 className="empty-title">No {config.title.toLowerCase()} available</h3>
            <button 
              onClick={() => router.push('/client')} 
              className="load-more-btn"
              style={{ background: config.color }}
            >
              🏠 Back to Home
            </button>
          </div>
        )}
      </main>

      <button className="sidebar-hamburger hamburger-left" onClick={() => setShowLeftSidebar(true)}>
        📚
      </button>

      <button className="sidebar-hamburger hamburger-right" onClick={() => setShowRightSidebar(true)}>
        🔥
      </button>

      {showLeftSidebar && (
        <>
          <div 
            className="mobile-sidebar-overlay active" 
            onClick={() => setShowLeftSidebar(false)} 
            role="button" 
            tabIndex={0}
          />
          <div className="mobile-sidebar-drawer left">
            <button className="mobile-sidebar-close" onClick={() => setShowLeftSidebar(false)}>×</button>
            <h3 className="sidebar-title">📚 Recent Updates</h3>
            <div className="sidebar-article-list">
              {recentNews.map((article: any) => (
                <div 
                  key={article.news_id} 
                  className="sidebar-article-item" 
                  onClick={() => { handleArticleClick(article); setShowLeftSidebar(false); }} 
                  role="button" 
                  tabIndex={0}
                >
                  <div className="sidebar-thumbnail">
                    {article.image_url ? (
                      <img 
                        src={getImageUrl(article.image_url) || ''} 
                        alt={article.title}
                        loading="lazy"
                        width="70"
                        height="70"
                      />
                    ) : (
                      <div className="thumbnail-placeholder">{config.icon}</div>
                    )}
                  </div>
                  <div className="sidebar-article-content">
                    <div className="sidebar-article-title">{article.title}</div>
                    <div className="sidebar-article-meta">
                      <span>{formatDate(article.published_at)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {showRightSidebar && (
        <>
          <div 
            className="mobile-sidebar-overlay active" 
            onClick={() => setShowRightSidebar(false)} 
            role="button" 
            tabIndex={0}
          />
          <div className="mobile-sidebar-drawer right">
            <button className="mobile-sidebar-close" onClick={() => setShowRightSidebar(false)}>×</button>
            <h3 className="sidebar-title">🔥 Most Popular</h3>
            <div className="sidebar-article-list">
              {popularNews.map((article: any, index: number) => (
                <div 
                  key={article.news_id} 
                  className="sidebar-article-item trending" 
                  onClick={() => { handleArticleClick(article); setShowRightSidebar(false); }} 
                  role="button" 
                  tabIndex={0}
                >
                  <div className="popularity-rank" style={{ background: config.color }}>
                    {index + 1}
                  </div>
                  <div className="sidebar-thumbnail">
                    {article.image_url ? (
                      <img 
                        src={getImageUrl(article.image_url) || ''} 
                        alt={article.title}
                        loading="lazy"
                        width="70"
                        height="70"
                      />
                    ) : (
                      <div className="thumbnail-placeholder">{config.icon}</div>
                    )}
                  </div>
                  <div className="sidebar-article-content">
                    <div className="sidebar-article-title">{article.title}</div>
                    <div className="sidebar-article-meta">
                      <span>{formatNumber(article.views)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      <button className="stories-btn" onClick={() => setShowGallery(true)} title="View Gallery">
        <div className="stories-icon">📸</div>
        <div className="stories-text">Stories</div>
      </button>

      <Footer />
    </div>
  );
}