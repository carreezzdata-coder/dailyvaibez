'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { formatDate, getImageUrl } from '../../../lib/clientData';
import { type Quote } from '../hooks/useQuotes';
import Header from '../components/Header';
import Horizontal from '../components/Horizontal';
import Footer from '../components/Footer';
import QuotesGallery from '../components/quotes/QuotesGallery';
import QuoteModal from '../components/quotes/QuoteModal';
import { getThemeColor } from '../components/quotes/QuotesUtils';

interface QuotesPageClientProps {
  initialData: {
    quotes: Quote[];
    strikingQuotes: Quote[];
    trendingQuotes: Quote[];
  };
}

function QuoteFlash({
  currentFlash,
  onClick,
}: {
  currentFlash: Quote | undefined;
  onClick: (quote: Quote) => void;
}) {
  if (!currentFlash) return null;

  const handleButtonKeyDown = (e: React.KeyboardEvent, callback: () => void) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      callback();
    }
  };

  return (
    <div className="quote-flash-banner">
      <div className="quote-flash-container">
        <div className="quote-flash-left">
          <span className="quote-flash-icon" aria-hidden="true">💬</span>
          <span className="quote-flash-label">QUOTE OF THE MOMENT</span>
        </div>
        
        <button 
          className="quote-flash-content"
          onClick={() => onClick(currentFlash)}
          onKeyDown={(e) => handleButtonKeyDown(e, () => onClick(currentFlash))}
          aria-label={`View quote by ${currentFlash.sayer_name}`}
        >
          {currentFlash.sayer_image_url && (
            <div className="quote-flash-avatar">
              <img src={getImageUrl(currentFlash.sayer_image_url)} alt={currentFlash.sayer_name} />
            </div>
          )}
          <div className="quote-flash-quote-mark">"</div>
          <div className="quote-flash-text-wrapper">
            <span className="quote-flash-text">{currentFlash.quote_text}</span>
            <span className="quote-flash-author">— {currentFlash.sayer_name}</span>
          </div>
        </button>
      </div>
    </div>
  );
}

export default function QuotesPageClient({ initialData }: QuotesPageClientProps) {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [currentTheme, setCurrentTheme] = useState('white');
  const [isHeaderVisible, setIsHeaderVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [flashIndex, setFlashIndex] = useState(0);
  const [selectedQuote, setSelectedQuote] = useState<Quote | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [shareUrl, setShareUrl] = useState('');
  const posterRef = React.useRef<HTMLDivElement>(null);

  const { quotes, strikingQuotes, trendingQuotes } = initialData;
  const flashQuotes = quotes.slice(0, 5);
  const currentFlash = flashQuotes[flashIndex];
  const themeColor = getThemeColor(currentTheme);

  useEffect(() => {
    setMounted(true);
    setShareUrl(window.location.href);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setFlashIndex((prev) => (prev + 1) % Math.min(5, flashQuotes.length));
    }, 4000);
    return () => clearInterval(interval);
  }, [flashQuotes.length]);

  const handleThemeChange = (theme: string) => {
    setCurrentTheme(theme);
    document.documentElement.setAttribute('data-theme', theme);
    if (typeof window !== 'undefined') {
      localStorage.setItem('vybes-theme', theme);
    }
  };

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('vybes-theme') || 'white';
      setCurrentTheme(savedTheme);
      document.documentElement.setAttribute('data-theme', savedTheme);
    }
  }, []);

  useEffect(() => {
    if (!mounted) return;

    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setIsHeaderVisible(false);
      } else {
        setIsHeaderVisible(true);
      }
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [mounted, lastScrollY]);

  const handleQuoteClick = (quote: Quote, index?: number) => {
    const quoteIndex = index !== undefined ? index : quotes.findIndex(q => q.quote_id === quote.quote_id);
    setSelectedQuote(quote);
    setCurrentIndex(quoteIndex !== -1 ? quoteIndex : 0);
  };

  const handleCloseModal = () => {
    setSelectedQuote(null);
  };

  const handleModalNavigation = (direction: 'prev' | 'next') => {
    if (direction === 'next' && currentIndex < quotes.length - 1) {
      const newIndex = currentIndex + 1;
      setCurrentIndex(newIndex);
      setSelectedQuote(quotes[newIndex]);
    } else if (direction === 'prev' && currentIndex > 0) {
      const newIndex = currentIndex - 1;
      setCurrentIndex(newIndex);
      setSelectedQuote(quotes[newIndex]);
    }
  };

  const handleShare = async (quote: Quote) => {
    const shareText = `*${quote.sayer_name}*\n\n"${quote.quote_text}"\n\n${formatDate(quote.created_at)}\n\n${shareUrl}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: quote.sayer_name,
          text: shareText,
          url: shareUrl,
        });
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          fallbackShare(shareText);
        }
      }
    } else {
      fallbackShare(shareText);
    }
  };

  const fallbackShare = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      alert('Quote copied to clipboard!');
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  useEffect(() => {
    const handleWindowKeyDown = (e: KeyboardEvent) => {
      if (selectedQuote && e.key === 'Escape') {
        handleCloseModal();
      } else if (selectedQuote && e.key === 'ArrowLeft') {
        handleModalNavigation('prev');
      } else if (selectedQuote && e.key === 'ArrowRight') {
        handleModalNavigation('next');
      }
    };

    window.addEventListener('keydown', handleWindowKeyDown);
    return () => window.removeEventListener('keydown', handleWindowKeyDown);
  }, [selectedQuote, currentIndex]);

  return (
    <div className="quotes-page">
      <div className={`header-wrapper ${isHeaderVisible ? 'visible' : 'hidden'}`}>
        <Header currentTheme={currentTheme} onThemeChange={handleThemeChange} />
      </div>
      <Horizontal activeCategory="quotes" />

      {mounted && (
        <QuoteFlash
          currentFlash={currentFlash}
          onClick={handleQuoteClick}
        />
      )}

      <main className="quotes-main-container">
        <div className="quotes-page-layout">
          <QuotesGallery
            allQuotes={quotes}
            currentTheme={currentTheme}
            onQuoteClick={handleQuoteClick}
          />
        </div>
      </main>

      {selectedQuote && (
        <QuoteModal
          selectedQuote={selectedQuote}
          currentIndex={currentIndex}
          totalQuotes={quotes.length}
          themeColor={themeColor}
          onClose={handleCloseModal}
          onNavigate={handleModalNavigation}
          onShare={handleShare}
          posterRef={posterRef}
        />
      )}

      <Footer />
    </div>
  );
}