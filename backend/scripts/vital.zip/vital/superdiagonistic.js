require('dotenv').config();
const { Client } = require('pg');
const fs = require('fs');

const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m',
};

const LOCAL_CONFIG = {
  host: 'localhost',
  port: 5432,
  database: 'dailyvaibe',
  user: 'postgres',
  password: 'dere84ELIJOOH'
};

const RENDER_CONFIG = {
  connectionString: 'postgresql://karisdailyvaibe:NjCBtk8SPXJDvQKtUVNCVedxJKsgyuCQ@dpg-d5saqdngi27c73dqp2dg-a.virginia-postgres.render.com/dailyvaibeschema',
  ssl: { rejectUnauthorized: false }
};

class SuperDiagnostic {
  constructor() {
    this.localClient = null;
    this.renderClient = null;
    this.differences = {
      tables: { missing: [], extra: [] },
      sequences: { missing: [], extra: [] },
      enums: { missing: [], extra: [] },
      functions: { missing: [], extra: [] },
      foreign_keys: { missing: [], extra: [] },
      indexes: { missing: [], extra: [] },
      triggers: { missing: [], extra: [] },
      views: { missing: [], extra: [] }
    };
    this.seedDataStatus = {
      categories: { local: 0, render: 0 },
      admins: { local: 0, render: 0 }
    };
  }

  log(message, color = 'reset') {
    console.log(`${colors[color]}${message}${colors.reset}`);
  }

  async connect() {
    this.log('\n🔌 CONNECTING TO DATABASES...', 'cyan');
    
    try {
      this.localClient = new Client(LOCAL_CONFIG);
      await this.localClient.connect();
      this.log('✅ Connected to LOCAL database', 'green');
      
      this.renderClient = new Client(RENDER_CONFIG);
      await this.renderClient.connect();
      this.log('✅ Connected to RENDER database', 'green');
    } catch (error) {
      this.log(`❌ Connection failed: ${error.message}`, 'red');
      throw error;
    }
  }

  async compareTables() {
    this.log('\n📋 COMPARING TABLES...', 'cyan');

    const localTables = await this.localClient.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_type = 'BASE TABLE'
      ORDER BY table_name
    `);

    const renderTables = await this.renderClient.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_type = 'BASE TABLE'
      ORDER BY table_name
    `);

    const localSet = new Set(localTables.rows.map(r => r.table_name));
    const renderSet = new Set(renderTables.rows.map(r => r.table_name));

    for (const table of localSet) {
      if (!renderSet.has(table)) {
        this.differences.tables.missing.push(table);
      }
    }

    for (const table of renderSet) {
      if (!localSet.has(table)) {
        this.differences.tables.extra.push(table);
      }
    }

    this.log(`  Local:  ${localSet.size} tables`, 'green');
    this.log(`  Render: ${renderSet.size} tables`, 'green');
    
    if (this.differences.tables.missing.length > 0) {
      this.log(`  ⚠️  Missing in Render: ${this.differences.tables.missing.length}`, 'yellow');
    }
    if (this.differences.tables.extra.length > 0) {
      this.log(`  ⚠️  Extra in Render: ${this.differences.tables.extra.length}`, 'yellow');
    }
    if (this.differences.tables.missing.length === 0 && this.differences.tables.extra.length === 0) {
      this.log('  ✓ Tables match perfectly', 'green');
    }
  }

  async compareSequences() {
    this.log('\n🔢 COMPARING SEQUENCES...', 'cyan');

    const localSeqs = await this.localClient.query(`
      SELECT sequence_name 
      FROM information_schema.sequences 
      WHERE sequence_schema = 'public'
      ORDER BY sequence_name
    `);

    const renderSeqs = await this.renderClient.query(`
      SELECT sequence_name 
      FROM information_schema.sequences 
      WHERE sequence_schema = 'public'
      ORDER BY sequence_name
    `);

    const localSet = new Set(localSeqs.rows.map(r => r.sequence_name));
    const renderSet = new Set(renderSeqs.rows.map(r => r.sequence_name));

    for (const seq of localSet) {
      if (!renderSet.has(seq)) {
        this.differences.sequences.missing.push(seq);
      }
    }

    for (const seq of renderSet) {
      if (!localSet.has(seq)) {
        this.differences.sequences.extra.push(seq);
      }
    }

    this.log(`  Local:  ${localSet.size} sequences`, 'green');
    this.log(`  Render: ${renderSet.size} sequences`, 'green');
    
    if (this.differences.sequences.missing.length === 0 && this.differences.sequences.extra.length === 0) {
      this.log('  ✓ Sequences match perfectly', 'green');
    } else {
      if (this.differences.sequences.missing.length > 0) {
        this.log(`  ⚠️  Missing in Render: ${this.differences.sequences.missing.length}`, 'yellow');
      }
      if (this.differences.sequences.extra.length > 0) {
        this.log(`  ⚠️  Extra in Render: ${this.differences.sequences.extra.length}`, 'yellow');
      }
    }
  }

  async compareEnums() {
    this.log('\n🎯 COMPARING ENUM TYPES...', 'cyan');

    const localEnums = await this.localClient.query(`
      SELECT typname 
      FROM pg_type t
      JOIN pg_namespace n ON t.typnamespace = n.oid
      WHERE t.typtype = 'e' 
      AND n.nspname = 'public'
      ORDER BY typname
    `);

    const renderEnums = await this.renderClient.query(`
      SELECT typname 
      FROM pg_type t
      JOIN pg_namespace n ON t.typnamespace = n.oid
      WHERE t.typtype = 'e' 
      AND n.nspname = 'public'
      ORDER BY typname
    `);

    const localSet = new Set(localEnums.rows.map(r => r.typname));
    const renderSet = new Set(renderEnums.rows.map(r => r.typname));

    for (const enumType of localSet) {
      if (!renderSet.has(enumType)) {
        this.differences.enums.missing.push(enumType);
      }
    }

    for (const enumType of renderSet) {
      if (!localSet.has(enumType)) {
        this.differences.enums.extra.push(enumType);
      }
    }

    this.log(`  Local:  ${localSet.size} enums`, 'green');
    this.log(`  Render: ${renderSet.size} enums`, 'green');
    
    if (this.differences.enums.missing.length === 0 && this.differences.enums.extra.length === 0) {
      this.log('  ✓ Enums match perfectly', 'green');
    } else {
      if (this.differences.enums.missing.length > 0) {
        this.log(`  ⚠️  Missing in Render: ${this.differences.enums.missing.length}`, 'yellow');
      }
      if (this.differences.enums.extra.length > 0) {
        this.log(`  ⚠️  Extra in Render: ${this.differences.enums.extra.length}`, 'yellow');
      }
    }
  }

  async compareForeignKeys() {
    this.log('\n🔗 COMPARING FOREIGN KEYS...', 'cyan');

    const fkQuery = `
      SELECT constraint_name
      FROM information_schema.table_constraints
      WHERE constraint_type = 'FOREIGN KEY'
      AND table_schema = 'public'
      ORDER BY constraint_name
    `;

    const localFKs = await this.localClient.query(fkQuery);
    const renderFKs = await this.renderClient.query(fkQuery);

    const localSet = new Set(localFKs.rows.map(r => r.constraint_name));
    const renderSet = new Set(renderFKs.rows.map(r => r.constraint_name));

    for (const fk of localSet) {
      if (!renderSet.has(fk)) {
        this.differences.foreign_keys.missing.push(fk);
      }
    }

    for (const fk of renderSet) {
      if (!localSet.has(fk)) {
        this.differences.foreign_keys.extra.push(fk);
      }
    }

    this.log(`  Local:  ${localSet.size} foreign keys`, 'green');
    this.log(`  Render: ${renderSet.size} foreign keys`, 'green');
    
    if (this.differences.foreign_keys.missing.length === 0 && this.differences.foreign_keys.extra.length === 0) {
      this.log('  ✓ Foreign keys match perfectly', 'green');
    } else {
      if (this.differences.foreign_keys.missing.length > 0) {
        this.log(`  ⚠️  Missing in Render: ${this.differences.foreign_keys.missing.length}`, 'yellow');
      }
      if (this.differences.foreign_keys.extra.length > 0) {
        this.log(`  ⚠️  Extra in Render: ${this.differences.foreign_keys.extra.length}`, 'yellow');
      }
    }
  }

  async compareIndexes() {
    this.log('\n📑 COMPARING INDEXES...', 'cyan');

    const indexQuery = `
      SELECT indexname
      FROM pg_indexes
      WHERE schemaname = 'public'
      ORDER BY indexname
    `;

    const localIndexes = await this.localClient.query(indexQuery);
    const renderIndexes = await this.renderClient.query(indexQuery);

    const localSet = new Set(localIndexes.rows.map(r => r.indexname));
    const renderSet = new Set(renderIndexes.rows.map(r => r.indexname));

    for (const idx of localSet) {
      if (!renderSet.has(idx)) {
        this.differences.indexes.missing.push(idx);
      }
    }

    for (const idx of renderSet) {
      if (!localSet.has(idx)) {
        this.differences.indexes.extra.push(idx);
      }
    }

    this.log(`  Local:  ${localSet.size} indexes`, 'green');
    this.log(`  Render: ${renderSet.size} indexes`, 'green');
    
    if (this.differences.indexes.missing.length === 0 && this.differences.indexes.extra.length === 0) {
      this.log('  ✓ Indexes match perfectly', 'green');
    } else {
      if (this.differences.indexes.missing.length > 0) {
        this.log(`  ⚠️  Missing in Render: ${this.differences.indexes.missing.length}`, 'yellow');
      }
      if (this.differences.indexes.extra.length > 0) {
        this.log(`  ⚠️  Extra in Render: ${this.differences.indexes.extra.length}`, 'yellow');
      }
    }
  }

  async compareFunctions() {
    this.log('\n⚙️  COMPARING FUNCTIONS...', 'cyan');

    const funcQuery = `
      SELECT p.proname 
      FROM pg_proc p
      JOIN pg_namespace n ON p.pronamespace = n.oid
      WHERE n.nspname = 'public'
      AND p.prokind = 'f'
      ORDER BY p.proname
    `;

    const localFuncs = await this.localClient.query(funcQuery);
    const renderFuncs = await this.renderClient.query(funcQuery);

    const localSet = new Set(localFuncs.rows.map(r => r.proname));
    const renderSet = new Set(renderFuncs.rows.map(r => r.proname));

    for (const func of localSet) {
      if (!renderSet.has(func)) {
        this.differences.functions.missing.push(func);
      }
    }

    for (const func of renderSet) {
      if (!localSet.has(func)) {
        this.differences.functions.extra.push(func);
      }
    }

    this.log(`  Local:  ${localSet.size} functions`, 'green');
    this.log(`  Render: ${renderSet.size} functions`, 'green');
    
    if (this.differences.functions.missing.length === 0 && this.differences.functions.extra.length === 0) {
      this.log('  ✓ Functions match perfectly', 'green');
    } else {
      if (this.differences.functions.missing.length > 0) {
        this.log(`  ⚠️  Missing in Render: ${this.differences.functions.missing.length}`, 'yellow');
      }
      if (this.differences.functions.extra.length > 0) {
        this.log(`  ⚠️  Extra in Render: ${this.differences.functions.extra.length}`, 'yellow');
      }
    }
  }

  async compareTriggers() {
    this.log('\n⚡ COMPARING TRIGGERS...', 'cyan');

    const triggerQuery = `
      SELECT tgname 
      FROM pg_trigger
      WHERE tgisinternal = false
      AND tgname NOT LIKE 'pg_%'
      ORDER BY tgname
    `;

    const localTriggers = await this.localClient.query(triggerQuery);
    const renderTriggers = await this.renderClient.query(triggerQuery);

    const localSet = new Set(localTriggers.rows.map(r => r.tgname));
    const renderSet = new Set(renderTriggers.rows.map(r => r.tgname));

    for (const trigger of localSet) {
      if (!renderSet.has(trigger)) {
        this.differences.triggers.missing.push(trigger);
      }
    }

    for (const trigger of renderSet) {
      if (!localSet.has(trigger)) {
        this.differences.triggers.extra.push(trigger);
      }
    }

    this.log(`  Local:  ${localSet.size} triggers`, 'green');
    this.log(`  Render: ${renderSet.size} triggers`, 'green');
    
    if (this.differences.triggers.missing.length === 0 && this.differences.triggers.extra.length === 0) {
      this.log('  ✓ Triggers match perfectly', 'green');
    } else {
      if (this.differences.triggers.missing.length > 0) {
        this.log(`  ⚠️  Missing in Render: ${this.differences.triggers.missing.length}`, 'yellow');
      }
      if (this.differences.triggers.extra.length > 0) {
        this.log(`  ⚠️  Extra in Render: ${this.differences.triggers.extra.length}`, 'yellow');
      }
    }
  }

  async compareViews() {
    this.log('\n👁️  COMPARING VIEWS...', 'cyan');

    const viewQuery = `
      SELECT table_name 
      FROM information_schema.views
      WHERE table_schema = 'public'
      ORDER BY table_name
    `;

    const localViews = await this.localClient.query(viewQuery);
    const renderViews = await this.renderClient.query(viewQuery);

    const localSet = new Set(localViews.rows.map(r => r.table_name));
    const renderSet = new Set(renderViews.rows.map(r => r.table_name));

    for (const view of localSet) {
      if (!renderSet.has(view)) {
        this.differences.views.missing.push(view);
      }
    }

    for (const view of renderSet) {
      if (!localSet.has(view)) {
        this.differences.views.extra.push(view);
      }
    }

    this.log(`  Local:  ${localSet.size} views`, 'green');
    this.log(`  Render: ${renderSet.size} views`, 'green');
    
    if (this.differences.views.missing.length === 0 && this.differences.views.extra.length === 0) {
      this.log('  ✓ Views match perfectly', 'green');
    } else {
      if (this.differences.views.missing.length > 0) {
        this.log(`  ⚠️  Missing in Render: ${this.differences.views.missing.length}`, 'yellow');
      }
      if (this.differences.views.extra.length > 0) {
        this.log(`  ⚠️  Extra in Render: ${this.differences.views.extra.length}`, 'yellow');
      }
    }
  }

  async checkSeedData() {
    this.log('\n🌱 CHECKING SEED DATA...', 'cyan');

    const checkCategories = async (client) => {
      const result = await client.query('SELECT COUNT(*) FROM categories');
      return parseInt(result.rows[0].count);
    };

    const checkAdmins = async (client) => {
      const result = await client.query('SELECT COUNT(*) FROM admins');
      return parseInt(result.rows[0].count);
    };

    try {
      this.seedDataStatus.categories.local = await checkCategories(this.localClient);
      this.seedDataStatus.categories.render = await checkCategories(this.renderClient);
      
      this.log(`  Categories - Local: ${this.seedDataStatus.categories.local}, Render: ${this.seedDataStatus.categories.render}`, 
        this.seedDataStatus.categories.local === this.seedDataStatus.categories.render ? 'green' : 'yellow');

      this.seedDataStatus.admins.local = await checkAdmins(this.localClient);
      this.seedDataStatus.admins.render = await checkAdmins(this.renderClient);
      
      this.log(`  Admins - Local: ${this.seedDataStatus.admins.local}, Render: ${this.seedDataStatus.admins.render}`, 
        this.seedDataStatus.admins.local === this.seedDataStatus.admins.render ? 'green' : 'yellow');

    } catch (error) {
      this.log(`  ⚠️  Could not check seed data: ${error.message}`, 'yellow');
    }
  }

  async installSeedData() {
    this.log('\n💉 INSTALLING SEED DATA TO RENDER...', 'magenta');

    try {
      const seedSQL = fs.readFileSync('seed-data-2026-01-25.sql', 'utf8');
      
      this.log('  Reading seed data file...', 'cyan');
      
      const statements = seedSQL
        .split(';')
        .map(s => s.trim())
        .filter(s => s.length > 0 && !s.startsWith('--'));

      this.log(`  Found ${statements.length} SQL statements`, 'cyan');

      await this.renderClient.query('BEGIN');
      
      let inserted = 0;
      for (const statement of statements) {
        try {
          await this.renderClient.query(statement);
          inserted++;
        } catch (error) {
          if (error.message.includes('duplicate key')) {
            this.log(`  ⚠️  Skipping duplicate: ${statement.substring(0, 60)}...`, 'yellow');
          } else {
            this.log(`  ❌ Error: ${error.message}`, 'red');
            this.log(`  Statement: ${statement.substring(0, 100)}...`, 'red');
          }
        }
      }

      await this.renderClient.query('COMMIT');
      
      this.log(`\n  ✅ Successfully executed ${inserted}/${statements.length} statements`, 'green');

      await this.checkSeedData();

    } catch (error) {
      await this.renderClient.query('ROLLBACK');
      this.log(`  ❌ Seed data installation failed: ${error.message}`, 'red');
      throw error;
    }
  }

  generateSummary() {
    this.log('\n' + '='.repeat(80), 'cyan');
    this.log('📊 SUPER DIAGNOSTIC SUMMARY', 'bright');
    this.log('='.repeat(80), 'cyan');

    const totalMissing = Object.values(this.differences).reduce((sum, diff) => sum + diff.missing.length, 0);
    const totalExtra = Object.values(this.differences).reduce((sum, diff) => sum + diff.extra.length, 0);

    this.log('\n🔍 SCHEMA COMPARISON RESULTS:', 'bright');
    
    Object.entries(this.differences).forEach(([type, diff]) => {
      if (diff.missing.length === 0 && diff.extra.length === 0) {
        this.log(`  ✅ ${type.toUpperCase()}: Perfect match`, 'green');
      } else {
        if (diff.missing.length > 0) {
          this.log(`  ⚠️  ${type.toUpperCase()}: ${diff.missing.length} missing in Render`, 'yellow');
          diff.missing.forEach(item => {
            this.log(`      - ${item}`, 'yellow');
          });
        }
        if (diff.extra.length > 0) {
          this.log(`  ⚠️  ${type.toUpperCase()}: ${diff.extra.length} extra in Render`, 'yellow');
          diff.extra.forEach(item => {
            this.log(`      - ${item}`, 'yellow');
          });
        }
      }
    });

    this.log('\n🌱 SEED DATA STATUS:', 'bright');
    this.log(`  Categories: Local=${this.seedDataStatus.categories.local}, Render=${this.seedDataStatus.categories.render}`, 
      this.seedDataStatus.categories.local === this.seedDataStatus.categories.render ? 'green' : 'yellow');
    this.log(`  Admins: Local=${this.seedDataStatus.admins.local}, Render=${this.seedDataStatus.admins.render}`, 
      this.seedDataStatus.admins.local === this.seedDataStatus.admins.render ? 'green' : 'yellow');

    this.log('\n' + '='.repeat(80), 'cyan');
    
    if (totalMissing === 0 && totalExtra === 0) {
      this.log('✅ DATABASES ARE PERFECTLY SYNCHRONIZED', 'green');
    } else {
      this.log('⚠️  DATABASES HAVE DIFFERENCES', 'yellow');
      this.log(`   Missing in Render: ${totalMissing} objects`, 'yellow');
      this.log(`   Extra in Render: ${totalExtra} objects`, 'yellow');
    }

    const categoriesMatch = this.seedDataStatus.categories.local === this.seedDataStatus.categories.render;
    const adminsMatch = this.seedDataStatus.admins.local === this.seedDataStatus.admins.render;
    
    if (categoriesMatch && adminsMatch) {
      this.log('✅ SEED DATA IS SYNCHRONIZED', 'green');
    } else {
      this.log('⚠️  SEED DATA NEEDS SYNCHRONIZATION', 'yellow');
    }

    this.log('='.repeat(80) + '\n', 'cyan');

    const report = {
      timestamp: new Date().toISOString(),
      schema_differences: this.differences,
      seed_data_status: this.seedDataStatus,
      summary: {
        total_missing: totalMissing,
        total_extra: totalExtra,
        schema_match: totalMissing === 0 && totalExtra === 0,
        seed_data_match: categoriesMatch && adminsMatch
      }
    };

    fs.writeFileSync('super_diagnostic_report.json', JSON.stringify(report, null, 2));
    this.log('📄 Detailed report saved to: super_diagnostic_report.json\n', 'cyan');

    return report.summary;
  }

  async run() {
    try {
      this.log('\n' + '='.repeat(80), 'magenta');
      this.log('🚀 DAILY VAIBE SUPER DIAGNOSTIC', 'bright');
      this.log('='.repeat(80) + '\n', 'magenta');

      await this.connect();
      
      await this.compareTables();
      await this.compareSequences();
      await this.compareEnums();
      await this.compareForeignKeys();
      await this.compareIndexes();
      await this.compareFunctions();
      await this.compareTriggers();
      await this.compareViews();
      
      await this.checkSeedData();

      const summary = this.generateSummary();

      const categoriesNeedSync = this.seedDataStatus.categories.local > this.seedDataStatus.categories.render;
      const adminsNeedSync = this.seedDataStatus.admins.local > this.seedDataStatus.admins.render;

      if (categoriesNeedSync || adminsNeedSync) {
        this.log('🔄 SEED DATA SYNCHRONIZATION REQUIRED', 'yellow');
        this.log('   Run with --install-seed flag to install seed data to Render\n', 'yellow');
        
        if (process.argv.includes('--install-seed')) {
          await this.installSeedData();
          this.log('\n✅ SEED DATA INSTALLATION COMPLETE', 'green');
        }
      }

    } catch (error) {
      this.log(`\n❌ DIAGNOSTIC FAILED: ${error.message}\n`, 'red');
      console.error(error.stack);
      process.exit(1);
    } finally {
      if (this.localClient) await this.localClient.end();
      if (this.renderClient) await this.renderClient.end();
    }
  }
}

const diagnostic = new SuperDiagnostic();
diagnostic.run();