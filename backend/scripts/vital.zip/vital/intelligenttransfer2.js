require('dotenv').config();
const { Client } = require('pg');

const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m',
};

const LOCAL_CONFIG = {
  host: 'localhost',
  port: 5432,
  database: 'dailyvaibe',
  user: 'postgres',
  password: 'dere84ELIJOOH'
};

const RENDER_CONFIG = {
  connectionString: 'postgresql://karisdailyvaibe:NjCBtk8SPXJDvQKtUVNCVedxJKsgyuCQ@dpg-d5saqdngi27c73dqp2dg-a.virginia-postgres.render.com/dailyvaibeschema',
  ssl: { rejectUnauthorized: false }
};

const SEED_TABLES = ['categories', 'admins'];

class BombproofSchemaTransfer {
  constructor() {
    this.sourceClient = null;
    this.targetClient = null;
    this.dependencies = new Map();
    this.exportOrder = [];
    this.stats = {
      extensions: 0,
      enums: 0,
      domains: 0,
      sequences: 0,
      tables: 0,
      foreignKeys: 0,
      indexes: 0,
      functions: 0,
      triggers: 0,
      views: 0,
      seedRecords: 0,
      errors: []
    };
  }

  log(message, color = 'reset') {
    console.log(`${colors[color]}${message}${colors.reset}`);
  }

  async connectSource() {
    this.sourceClient = new Client(LOCAL_CONFIG);
    await this.sourceClient.connect();
    this.log(`✅ Connected to source: ${LOCAL_CONFIG.database}`, 'green');
  }

  async connectTarget() {
    this.targetClient = new Client(RENDER_CONFIG);
    await this.targetClient.connect();
    this.log('✅ Connected to target: Render PostgreSQL\n', 'green');
  }

  async cleanTarget() {
    this.log('🧹 Cleaning target database...', 'cyan');
    
    try {
      await this.targetClient.query('DROP SCHEMA IF EXISTS public CASCADE');
      await this.targetClient.query('CREATE SCHEMA public');
      
      const permissionQueries = [
        'GRANT ALL ON SCHEMA public TO postgres',
        'GRANT ALL ON SCHEMA public TO public',
        'ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO postgres',
        'ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres',
        'ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres'
      ];

      for (const query of permissionQueries) {
        try {
          await this.targetClient.query(query);
        } catch (error) {
        }
      }
      
      this.log('✅ Target database cleaned\n', 'green');
    } catch (error) {
      this.log(`⚠️  Clean warning: ${error.message}\n`, 'yellow');
    }
  }

  async transferExtensions() {
    this.log('📦 Transferring extensions...', 'cyan');
    
    const extensions = await this.sourceClient.query(`
      SELECT extname 
      FROM pg_extension 
      WHERE extname NOT IN ('plpgsql')
      ORDER BY extname
    `);

    for (const ext of extensions.rows) {
      try {
        await this.targetClient.query(`CREATE EXTENSION IF NOT EXISTS "${ext.extname}"`);
        this.stats.extensions++;
        this.log(`  ✓ ${ext.extname}`, 'green');
      } catch (error) {
        this.log(`  ⚠️  ${ext.extname}: ${error.message.substring(0, 60)}`, 'yellow');
      }
    }
    this.log('');
  }

  async transferDomains() {
    this.log('📐 Transferring custom domains...', 'cyan');
    
    try {
      const domains = await this.sourceClient.query(`
        SELECT 
          t.typname,
          pg_catalog.format_type(t.typbasetype, t.typtypmod) as base_type,
          t.typnotnull,
          t.typdefault
        FROM pg_type t
        JOIN pg_namespace n ON t.typnamespace = n.oid
        WHERE t.typtype = 'd'
        AND n.nspname = 'public'
        ORDER BY t.typname
      `);

      for (const domain of domains.rows) {
        try {
          let sql = `CREATE DOMAIN public.${domain.typname} AS ${domain.base_type}`;
          if (domain.typnotnull) sql += ' NOT NULL';
          if (domain.typdefault) sql += ` DEFAULT ${domain.typdefault}`;
          
          await this.targetClient.query(sql);
          this.stats.domains++;
          this.log(`  ✓ ${domain.typname}`, 'green');
        } catch (error) {
          this.log(`  ⚠️  ${domain.typname}: ${error.message.substring(0, 60)}`, 'yellow');
        }
      }
    } catch (error) {
      this.log(`  ⚠️  Domains query failed: ${error.message}`, 'yellow');
    }
    this.log('');
  }

  async transferEnums() {
    this.log('🎯 Transferring ENUM types...', 'cyan');
    
    const enums = await this.sourceClient.query(`
      SELECT 
        t.typname,
        array_agg(e.enumlabel ORDER BY e.enumsortorder) as labels
      FROM pg_type t 
      JOIN pg_enum e ON t.oid = e.enumtypid  
      JOIN pg_namespace n ON t.typnamespace = n.oid
      WHERE n.nspname = 'public'
      GROUP BY t.typname
      ORDER BY t.typname
    `);

    for (const enumType of enums.rows) {
      try {
        let labelsArray = enumType.labels;
        if (typeof labelsArray === 'string') {
          labelsArray = labelsArray.replace(/^\{|\}$/g, '').split(',');
        }
        
        const labels = labelsArray.map(l => {
          const cleaned = String(l).trim().replace(/^"|"$/g, '');
          return `'${cleaned.replace(/'/g, "''")}'`;
        }).join(', ');
        
        await this.targetClient.query(`CREATE TYPE public.${enumType.typname} AS ENUM (${labels})`);
        this.stats.enums++;
        this.log(`  ✓ ${enumType.typname}`, 'green');
      } catch (error) {
        if (!error.message.includes('already exists')) {
          this.log(`  ⚠️  ${enumType.typname}: ${error.message.substring(0, 60)}`, 'yellow');
        }
      }
    }
    this.log('');
  }

  async transferSequences() {
    this.log('🔢 Transferring sequences...', 'cyan');
    
    const sequences = await this.sourceClient.query(`
      SELECT 
        c.relname as sequence_name,
        s.seqtypid::regtype as data_type,
        s.seqstart as start_value,
        s.seqincrement as increment_by,
        s.seqmin as min_value,
        s.seqmax as max_value,
        s.seqcache as cache_value,
        s.seqcycle as is_cycle,
        d.refobjid::regclass as owned_by_table,
        a.attname as owned_by_column
      FROM pg_class c
      JOIN pg_sequence s ON c.oid = s.seqrelid
      JOIN pg_namespace n ON c.relnamespace = n.oid
      LEFT JOIN pg_depend d ON d.objid = c.oid AND d.deptype = 'a'
      LEFT JOIN pg_attribute a ON a.attrelid = d.refobjid AND a.attnum = d.refobjsubid
      WHERE n.nspname = 'public'
      AND c.relkind = 'S'
      ORDER BY c.relname
    `);

    for (const seq of sequences.rows) {
      try {
        let sql = `CREATE SEQUENCE public.${seq.sequence_name}`;
        sql += ` AS ${seq.data_type}`;
        sql += ` START WITH ${seq.start_value}`;
        sql += ` INCREMENT BY ${seq.increment_by}`;
        if (seq.min_value !== null) sql += ` MINVALUE ${seq.min_value}`;
        else sql += ` NO MINVALUE`;
        if (seq.max_value !== null) sql += ` MAXVALUE ${seq.max_value}`;
        else sql += ` NO MAXVALUE`;
        sql += ` CACHE ${seq.cache_value}`;
        if (seq.is_cycle) sql += ` CYCLE`;
        
        await this.targetClient.query(sql);
        this.stats.sequences++;
        this.log(`  ✓ ${seq.sequence_name}`, 'green');
      } catch (error) {
        if (!error.message.includes('already exists')) {
          this.log(`  ⚠️  ${seq.sequence_name}: ${error.message.substring(0, 60)}`, 'yellow');
        }
      }
    }
    this.log('');
  }

  async analyzeDependencies() {
    this.log('🔍 Analyzing table dependencies...', 'cyan');
    
    const tables = await this.sourceClient.query(`
      SELECT 
        t.table_name,
        COALESCE(
          array_agg(
            DISTINCT ccu.table_name 
            ORDER BY ccu.table_name
          ) FILTER (WHERE ccu.table_name IS NOT NULL AND ccu.table_name != t.table_name),
          ARRAY[]::text[]
        ) as depends_on
      FROM information_schema.tables t
      LEFT JOIN information_schema.table_constraints tc 
        ON t.table_name = tc.table_name 
        AND tc.constraint_type = 'FOREIGN KEY'
      LEFT JOIN information_schema.constraint_column_usage ccu 
        ON tc.constraint_name = ccu.constraint_name
      WHERE t.table_schema = 'public' 
      AND t.table_type = 'BASE TABLE'
      GROUP BY t.table_name
      ORDER BY t.table_name
    `);

    for (const table of tables.rows) {
      let deps = table.depends_on;
      if (typeof deps === 'string') {
        deps = deps.replace(/^\{|\}$/g, '').split(',').filter(d => d);
      }
      this.dependencies.set(table.table_name, deps || []);
    }

    const visited = new Set();
    const visiting = new Set();

    const visit = (tableName) => {
      if (visited.has(tableName)) return;
      if (visiting.has(tableName)) return;

      visiting.add(tableName);
      const deps = this.dependencies.get(tableName) || [];
      
      for (const dep of deps) {
        if (this.dependencies.has(dep)) {
          visit(dep);
        }
      }

      visiting.delete(tableName);
      visited.add(tableName);
      this.exportOrder.push(tableName);
    };

    for (const tableName of this.dependencies.keys()) {
      visit(tableName);
    }

    this.log(`✓ Analyzed ${this.dependencies.size} tables\n`, 'green');
  }

  getColumnType(col) {
    let typeStr = '';
    
    if (col.udt_name === 'varchar') {
      typeStr = `VARCHAR${col.character_maximum_length ? '(' + col.character_maximum_length + ')' : ''}`;
    } else if (col.udt_name === 'bpchar') {
      typeStr = `CHAR${col.character_maximum_length ? '(' + col.character_maximum_length + ')' : ''}`;
    } else if (col.udt_name === 'text') {
      typeStr = 'TEXT';
    } else if (col.udt_name === 'int4') {
      typeStr = 'INTEGER';
    } else if (col.udt_name === 'int2') {
      typeStr = 'SMALLINT';
    } else if (col.udt_name === 'int8') {
      typeStr = 'BIGINT';
    } else if (col.udt_name === 'numeric') {
      if (col.numeric_precision && col.numeric_scale) {
        typeStr = `NUMERIC(${col.numeric_precision},${col.numeric_scale})`;
      } else if (col.numeric_precision) {
        typeStr = `NUMERIC(${col.numeric_precision})`;
      } else {
        typeStr = 'NUMERIC';
      }
    } else if (col.udt_name === 'float4') {
      typeStr = 'REAL';
    } else if (col.udt_name === 'float8') {
      typeStr = 'DOUBLE PRECISION';
    } else if (col.udt_name === 'bool') {
      typeStr = 'BOOLEAN';
    } else if (col.udt_name === 'date') {
      typeStr = 'DATE';
    } else if (col.udt_name === 'time') {
      typeStr = 'TIME';
    } else if (col.udt_name === 'timetz') {
      typeStr = 'TIME WITH TIME ZONE';
    } else if (col.udt_name === 'timestamp') {
      typeStr = 'TIMESTAMP';
    } else if (col.udt_name === 'timestamptz') {
      typeStr = 'TIMESTAMPTZ';
    } else if (col.udt_name === 'interval') {
      typeStr = 'INTERVAL';
    } else if (col.udt_name === 'uuid') {
      typeStr = 'UUID';
    } else if (col.udt_name === 'json') {
      typeStr = 'JSON';
    } else if (col.udt_name === 'jsonb') {
      typeStr = 'JSONB';
    } else if (col.udt_name === 'bytea') {
      typeStr = 'BYTEA';
    } else if (col.data_type === 'ARRAY') {
      const baseType = col.udt_name.replace(/^_/, '');
      typeStr = `${baseType.toUpperCase()}[]`;
    } else if (col.data_type === 'USER-DEFINED') {
      typeStr = `public.${col.udt_name}`;
    } else {
      typeStr = col.data_type.toUpperCase();
    }
    
    return typeStr;
  }

  async transferTables() {
    this.log('📋 Transferring tables in dependency order...', 'cyan');
    
    let successCount = 0;
    let failCount = 0;

    for (const tableName of this.exportOrder) {
      try {
        const columns = await this.sourceClient.query(`
          SELECT 
            column_name,
            data_type,
            udt_name,
            character_maximum_length,
            numeric_precision,
            numeric_scale,
            is_nullable,
            column_default
          FROM information_schema.columns
          WHERE table_schema = 'public' 
          AND table_name = $1
          ORDER BY ordinal_position
        `, [tableName]);

        if (columns.rows.length === 0) continue;

        const columnDefs = columns.rows.map(col => {
          let def = `  ${col.column_name} ${this.getColumnType(col)}`;
          
          if (col.column_default) {
            def += ` DEFAULT ${col.column_default}`;
          }
          
          if (col.is_nullable === 'NO') {
            def += ' NOT NULL';
          }
          
          return def;
        });

        const createSQL = `CREATE TABLE public.${tableName} (\n${columnDefs.join(',\n')}\n);`;
        
        await this.targetClient.query(createSQL);

        const checks = await this.sourceClient.query(`
          SELECT 
            cc.check_clause
          FROM information_schema.check_constraints cc
          JOIN information_schema.table_constraints tc 
            ON cc.constraint_name = tc.constraint_name
          WHERE tc.table_name = $1
          AND tc.table_schema = 'public'
          AND tc.constraint_type = 'CHECK'
        `, [tableName]);

        for (const check of checks.rows) {
          try {
            await this.targetClient.query(
              `ALTER TABLE public.${tableName} ADD CHECK ${check.check_clause}`
            );
          } catch (error) {
          }
        }

        successCount++;
        this.stats.tables++;
      } catch (error) {
        failCount++;
        this.log(`  ✗ ${tableName}: ${error.message.substring(0, 80)}`, 'red');
        this.stats.errors.push({ type: 'table', name: tableName, error: error.message });
      }
    }

    this.log(`  ✓ ${successCount} tables created`, 'green');
    if (failCount > 0) {
      this.log(`  ✗ ${failCount} tables failed`, 'red');
    }
    this.log('');
  }

  async transferPrimaryKeys() {
    this.log('🔑 Transferring primary keys...', 'cyan');
    
    const pks = await this.sourceClient.query(`
      SELECT 
        tc.table_name,
        tc.constraint_name,
        string_agg(kcu.column_name, ', ' ORDER BY kcu.ordinal_position) as columns
      FROM information_schema.table_constraints tc
      JOIN information_schema.key_column_usage kcu 
        ON tc.constraint_name = kcu.constraint_name
      WHERE tc.constraint_type = 'PRIMARY KEY'
      AND tc.table_schema = 'public'
      GROUP BY tc.table_name, tc.constraint_name
      ORDER BY tc.table_name
    `);

    let successCount = 0;
    for (const pk of pks.rows) {
      try {
        await this.targetClient.query(
          `ALTER TABLE public.${pk.table_name} ADD CONSTRAINT ${pk.constraint_name} PRIMARY KEY (${pk.columns})`
        );
        successCount++;
      } catch (error) {
      }
    }

    this.log(`  ✓ ${successCount} primary keys created`, 'green');
    this.log('');
  }

  async transferUniqueConstraints() {
    this.log('🔐 Transferring unique constraints...', 'cyan');
    
    const uniques = await this.sourceClient.query(`
      SELECT 
        tc.table_name,
        tc.constraint_name,
        string_agg(kcu.column_name, ', ' ORDER BY kcu.ordinal_position) as columns
      FROM information_schema.table_constraints tc
      JOIN information_schema.key_column_usage kcu 
        ON tc.constraint_name = kcu.constraint_name
      WHERE tc.constraint_type = 'UNIQUE'
      AND tc.table_schema = 'public'
      GROUP BY tc.table_name, tc.constraint_name
      ORDER BY tc.table_name
    `);

    let successCount = 0;
    for (const unique of uniques.rows) {
      try {
        await this.targetClient.query(
          `ALTER TABLE public.${unique.table_name} ADD CONSTRAINT ${unique.constraint_name} UNIQUE (${unique.columns})`
        );
        successCount++;
      } catch (error) {
      }
    }

    this.log(`  ✓ ${successCount} unique constraints created`, 'green');
    this.log('');
  }

  async transferForeignKeys() {
    this.log('🔗 Transferring foreign keys...', 'cyan');
    
    const fks = await this.sourceClient.query(`
      SELECT 
        tc.table_name,
        tc.constraint_name,
        kcu.column_name,
        ccu.table_name AS foreign_table_name,
        ccu.column_name AS foreign_column_name,
        rc.update_rule,
        rc.delete_rule
      FROM information_schema.table_constraints tc
      JOIN information_schema.key_column_usage kcu 
        ON tc.constraint_name = kcu.constraint_name
      JOIN information_schema.constraint_column_usage ccu 
        ON tc.constraint_name = ccu.constraint_name
      JOIN information_schema.referential_constraints rc 
        ON tc.constraint_name = rc.constraint_name
      WHERE tc.constraint_type = 'FOREIGN KEY'
      AND tc.table_schema = 'public'
      ORDER BY tc.table_name, tc.constraint_name
    `);

    let successCount = 0;
    for (const fk of fks.rows) {
      try {
        let sql = `ALTER TABLE public.${fk.table_name} `;
        sql += `ADD CONSTRAINT ${fk.constraint_name} `;
        sql += `FOREIGN KEY (${fk.column_name}) `;
        sql += `REFERENCES public.${fk.foreign_table_name}(${fk.foreign_column_name})`;
        if (fk.update_rule !== 'NO ACTION') sql += ` ON UPDATE ${fk.update_rule}`;
        if (fk.delete_rule !== 'NO ACTION') sql += ` ON DELETE ${fk.delete_rule}`;
        
        await this.targetClient.query(sql);
        successCount++;
        this.stats.foreignKeys++;
      } catch (error) {
      }
    }

    this.log(`  ✓ ${successCount} foreign keys created`, 'green');
    this.log('');
  }

  async transferIndexes() {
    this.log('📇 Transferring indexes...', 'cyan');
    
    const indexes = await this.sourceClient.query(`
      SELECT indexdef
      FROM pg_indexes
      WHERE schemaname = 'public'
      AND indexname NOT LIKE '%_pkey'
      AND indexname NOT LIKE 'pg_%'
      ORDER BY tablename, indexname
    `);

    let successCount = 0;
    for (const idx of indexes.rows) {
      try {
        await this.targetClient.query(idx.indexdef);
        successCount++;
        this.stats.indexes++;
      } catch (error) {
      }
    }

    this.log(`  ✓ ${successCount} indexes created`, 'green');
    this.log('');
  }

  async transferFunctions() {
    this.log('⚙️  Transferring functions...', 'cyan');
    
    const functions = await this.sourceClient.query(`
      SELECT 
        p.proname as function_name,
        pg_get_functiondef(p.oid) as definition
      FROM pg_proc p
      JOIN pg_namespace n ON p.pronamespace = n.oid
      WHERE n.nspname = 'public'
      AND p.prokind = 'f'
      ORDER BY p.proname
    `);

    let successCount = 0;
    for (const func of functions.rows) {
      try {
        await this.targetClient.query(func.definition);
        successCount++;
        this.stats.functions++;
      } catch (error) {
        if (!error.message.toLowerCase().includes('permission denied')) {
          this.log(`  ⚠️  ${func.function_name}: ${error.message.substring(0, 60)}`, 'yellow');
        }
      }
    }

    this.log(`  ✓ ${successCount} functions created`, 'green');
    this.log('');
  }

  async transferTriggers() {
    this.log('⚡ Transferring triggers...', 'cyan');
    
    const triggers = await this.sourceClient.query(`
      SELECT 
        tgname,
        pg_get_triggerdef(oid) as definition
      FROM pg_trigger
      WHERE tgisinternal = false
      AND tgname NOT LIKE 'pg_%'
      ORDER BY tgname
    `);

    let successCount = 0;
    for (const trig of triggers.rows) {
      try {
        await this.targetClient.query(trig.definition);
        successCount++;
        this.stats.triggers++;
      } catch (error) {
        if (!error.message.toLowerCase().includes('permission denied') && 
            !error.message.toLowerCase().includes('already exists')) {
          this.log(`  ⚠️  ${trig.tgname}: ${error.message.substring(0, 60)}`, 'yellow');
        }
      }
    }

    this.log(`  ✓ ${successCount} triggers created`, 'green');
    this.log('');
  }

  async transferViews() {
    this.log('👁️  Transferring views...', 'cyan');
    
    const views = await this.sourceClient.query(`
      SELECT 
        table_name,
        view_definition
      FROM information_schema.views
      WHERE table_schema = 'public'
      ORDER BY table_name
    `);

    let successCount = 0;
    for (const view of views.rows) {
      try {
        await this.targetClient.query(
          `CREATE VIEW public.${view.table_name} AS ${view.view_definition}`
        );
        successCount++;
        this.stats.views++;
      } catch (error) {
        if (!error.message.includes('already exists')) {
          this.log(`  ⚠️  ${view.table_name}: ${error.message.substring(0, 60)}`, 'yellow');
        }
      }
    }

    this.log(`  ✓ ${successCount} views created`, 'green');
    this.log('');
  }

  async transferSeedData() {
    this.log('🌱 Transferring seed data...', 'cyan');
    
    for (const tableName of SEED_TABLES) {
      try {
        const exists = await this.targetClient.query(`
          SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name = $1
          )
        `, [tableName]);

        if (!exists.rows[0].exists) {
          this.log(`  ⚠️  ${tableName}: table does not exist`, 'yellow');
          continue;
        }

        const data = await this.sourceClient.query(`SELECT * FROM ${tableName} ORDER BY 1`);
        
        if (data.rows.length === 0) {
          this.log(`  ⚠️  ${tableName}: no data to transfer`, 'yellow');
          continue;
        }

        const columns = Object.keys(data.rows[0]);
        let insertedCount = 0;

        for (const row of data.rows) {
          const values = columns.map((col, idx) => `$${idx + 1}`).join(', ');
          const columnsList = columns.join(', ');
          
          try {
            await this.targetClient.query(
              `INSERT INTO ${tableName} (${columnsList}) VALUES (${values})`,
              columns.map(col => row[col])
            );
            insertedCount++;
            this.stats.seedRecords++;
          } catch (error) {
            if (!error.message.includes('duplicate')) {
              this.log(`    ⚠️  Row failed: ${error.message.substring(0, 50)}`, 'yellow');
            }
          }
        }

        this.log(`  ✓ ${tableName}: ${insertedCount} records inserted`, 'green');

        const seqResult = await this.sourceClient.query(`
          SELECT pg_get_serial_sequence($1, c.column_name) as seq_name
          FROM information_schema.columns c
          WHERE c.table_name = $1
          AND c.column_default LIKE 'nextval%'
          LIMIT 1
        `, [tableName]);

        if (seqResult.rows.length > 0 && seqResult.rows[0].seq_name) {
          const seqName = seqResult.rows[0].seq_name.replace('public.', '');
          await this.targetClient.query(
            `SELECT setval('${seqName}', (SELECT COALESCE(MAX(${columns[0]}), 1) FROM ${tableName}), true)`
          );
        }

      } catch (error) {
        this.log(`  ✗ ${tableName}: ${error.message}`, 'red');
      }
    }
    this.log('');
  }

  async generateReport() {
    this.log('='.repeat(80), 'cyan');
    this.log('📊 TRANSFER SUMMARY', 'bright');
    this.log('='.repeat(80), 'cyan');

    try {
      const stats = {
        tables: await this.targetClient.query(`SELECT COUNT(*) FROM pg_tables WHERE schemaname = 'public'`),
        sequences: await this.targetClient.query(`SELECT COUNT(*) FROM pg_sequences WHERE schemaname = 'public'`),
        enums: await this.targetClient.query(`SELECT COUNT(*) FROM pg_type WHERE typtype = 'e' AND typnamespace = 'public'::regnamespace`),
        functions: await this.targetClient.query(`SELECT COUNT(*) FROM pg_proc p JOIN pg_namespace n ON p.pronamespace = n.oid WHERE n.nspname = 'public' AND p.prokind = 'f'`),
        indexes: await this.targetClient.query(`SELECT COUNT(*) FROM pg_indexes WHERE schemaname = 'public'`),
        fks: await this.targetClient.query(`SELECT COUNT(*) FROM information_schema.table_constraints WHERE constraint_type = 'FOREIGN KEY' AND table_schema = 'public'`),
        triggers: await this.targetClient.query(`SELECT COUNT(*) FROM pg_trigger WHERE tgisinternal = false`),
        views: await this.targetClient.query(`SELECT COUNT(*) FROM information_schema.views WHERE table_schema = 'public'`)
      };

      this.log(`\n   Extensions:     ${this.stats.extensions}`, 'green');
      this.log(`   ENUM Types:     ${this.stats.enums}`, 'green');
      this.log(`   Domains:        ${this.stats.domains}`, 'green');
      this.log(`   Sequences:      ${stats.sequences.rows[0].count}`, 'green');
      this.log(`   Functions:      ${this.stats.functions}`, 'green');
      this.log(`   Tables:         ${stats.tables.rows[0].count}`, 'green');
      this.log(`   Views:          ${stats.views.rows[0].count}`, 'green');
      this.log(`   Indexes:        ${stats.indexes.rows[0].count}`, 'green');
      this.log(`   Foreign Keys:   ${stats.fks.rows[0].count}`, 'green');
      this.log(`   Triggers:       ${stats.triggers.rows[0].count}`, 'green');
      this.log(`   Seed Records:   ${this.stats.seedRecords}`, 'green');

      if (this.stats.errors.length > 0) {
        this.log(`\n   ⚠️  Errors: ${this.stats.errors.length}`, 'yellow');
        for (const err of this.stats.errors.slice(0, 5)) {
          this.log(`      ${err.name}: ${err.error.substring(0, 60)}`, 'yellow');
        }
      }

    } catch (error) {
      this.log(`⚠️  Could not generate full report: ${error.message}`, 'yellow');
    }

    this.log('\n' + '='.repeat(80), 'cyan');
    if (this.stats.errors.length < 5) {
      this.log('✅ SCHEMA TRANSFER COMPLETE - SUCCESS', 'green');
    } else {
      this.log('⚠️  SCHEMA TRANSFER COMPLETE - WITH WARNINGS', 'yellow');
    }
    this.log('='.repeat(80) + '\n', 'cyan');
  }

  async transfer() {
    try {
      this.log('🚀 Bombproof Schema Transfer - Local to Render\n', 'magenta');
      
      await this.connectSource();
      await this.connectTarget();
      await this.cleanTarget();
      await this.transferExtensions();
      await this.transferDomains();
      await this.transferEnums();
      await this.transferSequences();
      await this.analyzeDependencies();
      await this.transferTables();
      await this.transferPrimaryKeys();
      await this.transferUniqueConstraints();
      await this.transferForeignKeys();
      await this.transferIndexes();
      await this.transferFunctions();
      await this.transferTriggers();
      await this.transferViews();
      await this.transferSeedData();
      await this.generateReport();

    } catch (error) {
      this.log(`\n❌ TRANSFER FAILED: ${error.message}\n`, 'red');
      console.error(error.stack);
      process.exit(1);
    } finally {
      if (this.sourceClient) await this.sourceClient.end();
      if (this.targetClient) await this.targetClient.end();
    }
  }
}

const transferer = new BombproofSchemaTransfer();
transferer.transfer();